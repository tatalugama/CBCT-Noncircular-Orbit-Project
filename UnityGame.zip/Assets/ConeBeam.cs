using UnityEngine;
using System.Collections.Generic;

public class ConeSmear : MonoBehaviour
{
    [Header("Smear Settings")]
    [SerializeField] float angleThreshold = 2f; // degrees of movement before placing a new ghost
    [SerializeField] Material smearMaterial;    // assign a transparent material in Inspector
    [SerializeField] float baseAlpha = 0.05f;   // alpha per ghost � more overlaps = darker

    Quaternion lastRotation;
    List<GameObject> ghosts = new List<GameObject>();

    void Start()
    {
        lastRotation = transform.rotation;
    }

    void Update()
    {
        float angleMoved = Quaternion.Angle(lastRotation, transform.rotation);

        if (angleMoved >= angleThreshold)
        {
            PlaceGhost();
            lastRotation = transform.rotation;
        }
    }

    void PlaceGhost()
    {
        // Duplicate this object's mesh as a ghost
        GameObject ghost = new GameObject("SmearGhost");
        ghost.transform.position = transform.position;
        ghost.transform.rotation = transform.rotation;
        ghost.transform.localScale = transform.lossyScale;

        MeshFilter mf = ghost.AddComponent<MeshFilter>();
        MeshRenderer mr = ghost.AddComponent<MeshRenderer>();

        MeshFilter sourceMF = GetComponent<MeshFilter>();
        if (sourceMF != null)
            mf.mesh = sourceMF.mesh;

        // Create a new material instance so alpha is independent per ghost
        Material ghostMat = new Material(smearMaterial);
        Color c = ghostMat.color;
        c.a = baseAlpha;
        ghostMat.color = c;
        mr.material = ghostMat;

        ghosts.Add(ghost);
    }

    public void ClearSmear()
    {
        foreach (var g in ghosts)
            if (g != null) Destroy(g);
        ghosts.Clear();
    }
}