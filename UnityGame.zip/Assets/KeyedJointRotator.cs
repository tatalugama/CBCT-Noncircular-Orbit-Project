using UnityEngine;
using UnityEngine.InputSystem;

public class KeyedJointRotator : MonoBehaviour
{
    public enum Axis { Right, Up, Forward }

    [Header("Axis")]
    [SerializeField] Axis rotationAxis;

    [Header("Input")]
    [SerializeField] Key activationKey = Key.Digit1;
    [SerializeField] Key positiveKey = Key.UpArrow;
    [SerializeField] Key negativeKey = Key.DownArrow;

    [Header("Sensitivity")]
    [SerializeField] float mouseSensitivity = 0.3f;
    [SerializeField] float arrowSensitivity = 60f;

    [Header("Angle Limits")]
    [SerializeField] bool clampAngle = false;
    [SerializeField] float minAngle = -45f;
    [SerializeField] float maxAngle = 45f;

    float currentAngle = 0f;

    Vector3 GetAxis()
    {
        switch (rotationAxis)
        {
            case Axis.Right: return Vector3.right;
            case Axis.Up: return Vector3.up;
            default: return Vector3.forward;
        }
    }

    void ApplyRotation(float delta)
    {
        if (clampAngle)
        {
            float newAngle = Mathf.Clamp(currentAngle + delta, minAngle, maxAngle);
            float actualDelta = newAngle - currentAngle;
            currentAngle = newAngle;
            transform.Rotate(GetAxis(), actualDelta, Space.Self);
        }
        else
        {
            transform.Rotate(GetAxis(), delta, Space.Self);
        }
    }

    void Update()
    {
        if (Keyboard.current[activationKey].isPressed)
        {
            Vector2 mouseDelta = Mouse.current.delta.ReadValue();
            float rotation = (mouseDelta.x + mouseDelta.y) * mouseSensitivity;
            if (rotation != 0f) ApplyRotation(rotation);

            if (Keyboard.current[positiveKey].isPressed)
                ApplyRotation(arrowSensitivity * Time.deltaTime);
            if (Keyboard.current[negativeKey].isPressed)
                ApplyRotation(-arrowSensitivity * Time.deltaTime);
        }
    }
}