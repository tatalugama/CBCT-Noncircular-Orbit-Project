using UnityEngine;
using UnityEngine.InputSystem;

public class LinearAxisMover : MonoBehaviour
{
    public enum Axis { X, Y, Z }

    [Header("Axis")]
    public Axis moveAxis;
    public bool useLocalSpace = true;

    [Header("Input")]
    [SerializeField] Key activationKey = Key.Digit4;
    [SerializeField] Key positiveKey = Key.UpArrow;
    [SerializeField] Key negativeKey = Key.DownArrow;

    [Header("Speed")]
    [SerializeField] float moveSpeed = 1f; // units per second

    [Header("Limits (PLACEHOLDER - replace with real spec values)")]
    [SerializeField] bool clampPosition = true;
    [SerializeField] float minValue = -1f;
    [SerializeField] float maxValue = 1f;

    float currentValue = 0f;

    Vector3 GetDirection()
    {
        switch (moveAxis)
        {
            case Axis.X: return useLocalSpace ? transform.right : Vector3.right;
            case Axis.Y: return useLocalSpace ? transform.up : Vector3.up;
            default: return useLocalSpace ? transform.forward : Vector3.forward;
        }
    }

    void Update()
    {
        if (!Keyboard.current[activationKey].isPressed) return;

        float delta = 0f;
        if (Keyboard.current[positiveKey].isPressed) delta += moveSpeed * Time.deltaTime;
        if (Keyboard.current[negativeKey].isPressed) delta -= moveSpeed * Time.deltaTime;

        if (delta == 0f) return;

        if (clampPosition)
        {
            float newValue = Mathf.Clamp(currentValue + delta, minValue, maxValue);
            float actualDelta = newValue - currentValue;
            currentValue = newValue;
            transform.position += GetDirection() * actualDelta;
        }
        else
        {
            transform.position += GetDirection() * delta;
            currentValue += delta;
        }
    }
}