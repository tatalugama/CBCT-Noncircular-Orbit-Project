using UnityEngine;

public class Hinge : MonoBehaviour { }