﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class DOFSequenceBuilder : MonoBehaviour
{
    [Header("Rotational Joints")]
    [SerializeField] Transform inPlaneJoint;
    [SerializeField] Transform cranioCaudalJoint;
    [SerializeField] Transform lateralJoint;

    [Header("Translational Joints")]
    [SerializeField] Transform gantryJoint;
    [SerializeField] Transform columnHeightJoint;
    [SerializeField] Transform gantryLRJoint;

    [Header("Translation Directions (world space, per DOF)")]
    [SerializeField] Vector3 gantryDir = Vector3.right;
    [SerializeField] Vector3 columnHeightDir = Vector3.up;
    [SerializeField] Vector3 gantryLRDir = Vector3.forward;

    [Header("Export")]
    [SerializeField] Transform focalSpot;
    [SerializeField] int numProjections = 100;

    [Header("Loop")]
    [SerializeField] bool loop = true;

    [Header("Orbit Import")]
    [SerializeField] string importPath = "orbit_results_orbit.csv";
    string importStatus = "";

    enum DOF { Lateral, CranioCaudal, InPlane, Gantry, ColumnHeight, GantryLR }
    string[] dofLabels = { "Lateral", "CranioCaudal", "InPlane", "Gantry", "ColumnHeight", "Gantry LR" };

    class StepRow
    {
        public DOF dof = DOF.Lateral;
        public string valueInput = "0";
        public string durationInput = "1";
        public bool waitForPrevious = true;
        public bool smooth = false;
    }

    List<StepRow> rows = new List<StepRow>();
    bool isPlaying = false;
    Coroutine playCoroutine;
    string statusText = "Ready";

    Vector3 gantryStartLocal;
    Vector3 columnHeightStartLocal;
    Vector3 gantryLRStartLocal;

    int viewMode = 0;
    List<GameObject> hiddenObjects = new List<GameObject>();
    HashSet<MeshRenderer> editorDisabledRenderers = new HashSet<MeshRenderer>();

    int dragIndex = -1;
    float rowHeight = 30f;
    float listStartY = 55f;
    Vector2 scrollPosition = Vector2.zero;

    void Start()
    {
        rows.Add(new StepRow());

        if (gantryJoint) gantryStartLocal = gantryJoint.localPosition;
        if (columnHeightJoint) columnHeightStartLocal = columnHeightJoint.localPosition;
        if (gantryLRJoint) gantryLRStartLocal = gantryLRJoint.localPosition;

        MeshRenderer[] allRenderers = FindObjectsOfType<MeshRenderer>(true);
        foreach (MeshRenderer mr in allRenderers)
            if (!mr.enabled) editorDisabledRenderers.Add(mr);
    }

    // ── Lookups ───────────────────────────────────────────────────────────────

    Transform GetJoint(DOF dof)
    {
        switch (dof)
        {
            case DOF.Lateral: return lateralJoint;
            case DOF.CranioCaudal: return cranioCaudalJoint;
            case DOF.InPlane: return inPlaneJoint;
            case DOF.Gantry: return gantryJoint;
            case DOF.ColumnHeight: return columnHeightJoint;
            default: return gantryLRJoint;
        }
    }

    bool IsRotational(DOF dof)
    {
        return dof == DOF.InPlane || dof == DOF.CranioCaudal || dof == DOF.Lateral;
    }

    Vector3 GetLocalAxis(DOF dof)
    {
        switch (dof)
        {
            case DOF.Lateral: return Vector3.right;
            case DOF.CranioCaudal: return Vector3.up;
            case DOF.InPlane: return Vector3.forward;
            default: return Vector3.forward;
        }
    }

    Vector3 GetTranslationDirWorld(DOF dof)
    {
        switch (dof)
        {
            case DOF.Gantry: return gantryDir.sqrMagnitude > 0f ? gantryDir.normalized : Vector3.right;
            case DOF.ColumnHeight: return columnHeightDir.sqrMagnitude > 0f ? columnHeightDir.normalized : Vector3.up;
            case DOF.GantryLR: return gantryLRDir.sqrMagnitude > 0f ? gantryLRDir.normalized : Vector3.forward;
            default: return Vector3.right;
        }
    }

    Vector3 ToParentSpace(Transform joint, Vector3 worldDir)
    {
        return joint.parent != null
            ? joint.parent.InverseTransformDirection(worldDir)
            : worldDir;
    }

    Vector3 GetStartLocal(DOF dof)
    {
        switch (dof)
        {
            case DOF.Gantry: return gantryStartLocal;
            case DOF.ColumnHeight: return columnHeightStartLocal;
            default: return gantryLRStartLocal;
        }
    }

    // ── GUI ───────────────────────────────────────────────────────────────────

    void OnGUI()
    {
        float y = 10;
        float boxHeight = 70 + rows.Count * rowHeight + 230;
        float panelHeight = Mathf.Min(boxHeight, Screen.height - 20);

        GUI.Box(new Rect(10, y, 580, panelHeight), "DOF Sequence Builder");
        y += 25;

        scrollPosition = GUI.BeginScrollView(
            new Rect(10, y, 580, panelHeight - 25),
            scrollPosition,
            new Rect(0, 0, 560, boxHeight)
        );
        y = 0;

        GUI.Label(new Rect(20, y, 20, 20), "≡");
        GUI.Label(new Rect(42, y, 110, 20), "DOF");
        GUI.Label(new Rect(155, y, 20, 20), "=");
        GUI.Label(new Rect(175, y, 55, 20), "Value");
        GUI.Label(new Rect(235, y, 50, 20), "Dur(s)");
        GUI.Label(new Rect(295, y, 70, 20), "Wait prev");
        GUI.Label(new Rect(368, y, 50, 20), "Smooth");
        y += 20;

        listStartY = y;
        Event e = Event.current;

        for (int i = 0; i < rows.Count; i++)
        {
            float rowY = y + i * rowHeight;

            if (dragIndex == i)
            {
                rowY = e.mousePosition.y - rowHeight / 2f;
                GUI.color = new Color(1f, 1f, 0.5f, 0.8f);
            }
            else if (dragIndex >= 0)
            {
                int targetIndex = Mathf.Clamp(
                    Mathf.RoundToInt((e.mousePosition.y - listStartY) / rowHeight),
                    0, rows.Count - 1);
                if (i == targetIndex)
                    GUI.color = new Color(0.7f, 1f, 0.7f, 1f);
            }

            StepRow row = rows[i];
            float x = 20;

            Rect handleRect = new Rect(x, rowY + 3, 18, 20);
            GUI.Label(handleRect, "≡");
            if (e.type == EventType.MouseDown && handleRect.Contains(e.mousePosition))
            {
                dragIndex = i;
                e.Use();
            }
            x += 22;

            if (GUI.Button(new Rect(x, rowY, 110, 25), dofLabels[(int)row.dof]))
                row.dof = (DOF)(((int)row.dof + 1) % 6);
            x += 115;

            GUI.Label(new Rect(x, rowY, 15, 25), "=");
            x += 20;

            row.valueInput = GUI.TextField(new Rect(x, rowY, 55, 25), row.valueInput);
            x += 60;

            row.durationInput = GUI.TextField(new Rect(x, rowY, 40, 25), row.durationInput);
            x += 50;

            row.waitForPrevious = GUI.Toggle(new Rect(x + 15, rowY + 3, 20, 20), row.waitForPrevious, "");
            x += 70;

            row.smooth = GUI.Toggle(new Rect(x + 10, rowY + 3, 20, 20), row.smooth, "");
            x += 60;

            if (GUI.Button(new Rect(x, rowY, 25, 25), "X"))
            {
                rows.RemoveAt(i);
                if (dragIndex >= i) dragIndex = -1;
                break;
            }

            GUI.color = Color.white;
        }

        if (e.type == EventType.MouseUp && dragIndex >= 0)
        {
            int targetIndex = Mathf.Clamp(
                Mathf.RoundToInt((e.mousePosition.y - listStartY) / rowHeight),
                0, rows.Count - 1);
            if (targetIndex != dragIndex)
            {
                StepRow dragged = rows[dragIndex];
                rows.RemoveAt(dragIndex);
                rows.Insert(targetIndex, dragged);
            }
            dragIndex = -1;
            e.Use();
        }

        if (dragIndex >= 0) GUI.changed = true;

        y += rows.Count * rowHeight + 5;

        // Row 1: Add, Reset, Validate
        if (GUI.Button(new Rect(20, y, 150, 28), "+ Add Step"))
            rows.Add(new StepRow());
        if (GUI.Button(new Rect(180, y, 150, 28), "Reset to Zero"))
            ResetToZero();
        if (GUI.Button(new Rect(340, y, 150, 28), "Validate Setup"))
            ValidateSetup();

        y += 35;

        // Row 2: Import orbit
        if (GUI.Button(new Rect(20, y, 160, 28), "Import Orbit CSV"))
        {
            string fullPath = Path.Combine(Application.dataPath, importPath);
            ImportOrbit(fullPath);
        }
        if (importStatus != "")
            GUI.Label(new Rect(190, y, 380, 28), importStatus);

        y += 35;

        // Row 3: Trace controls
        ConeSmear smear = FindObjectOfType<ConeSmear>();
        if (smear != null)
        {
            if (GUI.Button(new Rect(20, y, 120, 28), "Clear Trace"))
                smear.ClearSmear();
            string[] modeLabels = { "Normal View", "Trace Only", "No Trace" };
            if (GUI.Button(new Rect(150, y, 120, 28), modeLabels[viewMode]))
                SetViewMode((viewMode + 1) % 3, smear);
            GUI.Label(new Rect(280, y, 200, 28), $"Mode: {modeLabels[viewMode]}");
        }

        y += 35;

        // Row 4: Export
        if (GUI.Button(new Rect(20, y, 200, 28), "Export Source Positions"))
        {
            if (focalSpot == null)
                statusText = "ERROR: Focal Spot not assigned in Inspector";
            else
                StartCoroutine(ExportSourcePositions());
        }
        GUI.Label(new Rect(230, y, 340, 28), $"Projections: {numProjections}");

        y += 35;

        // Row 5: Loop + Play/Stop
        loop = GUI.Toggle(new Rect(20, y + 4, 20, 20), loop, "");
        GUI.Label(new Rect(42, y + 4, 50, 20), "Loop");

        if (!isPlaying)
        {
            if (GUI.Button(new Rect(100, y, 100, 28), "Play"))
            {
                isPlaying = true;
                playCoroutine = StartCoroutine(PlaySequence());
            }
        }
        else
        {
            if (GUI.Button(new Rect(100, y, 100, 28), "Stop"))
            {
                StopCoroutine(playCoroutine);
                isPlaying = false;
                statusText = "Stopped";
            }
        }

        y += 35;
        GUI.Label(new Rect(20, y, 550, 25), statusText);

        GUI.EndScrollView();
    }

    // ── Import ────────────────────────────────────────────────────────────────

    void ImportOrbit(string path)
    {
        if (!File.Exists(path))
        {
            importStatus = $"File not found: {path}";
            return;
        }

        try
        {
            string[] lines = File.ReadAllLines(path);
            if (lines.Length < 2)
            {
                importStatus = "CSV file is empty or has no data rows";
                return;
            }

            string[] headers = lines[0].Split(',');
            var colIndex = new Dictionary<string, int>();
            for (int i = 0; i < headers.Length; i++)
                colIndex[headers[i].Trim()] = i;

            string[] fieldNames = {
                "Lateral_deg", "CranioCaudal_deg", "InPlane_deg",
                "Gantry_cm", "ColumnHeight_cm", "GantryLR_cm"
            };

            rows.Clear();
            int stepCount = 0;

            for (int li = 1; li < lines.Length; li++)
            {
                string line = lines[li].Trim();
                if (string.IsNullOrEmpty(line)) continue;

                string[] parts = line.Split(',');
                float[] vals = new float[6];

                for (int d = 0; d < 6; d++)
                {
                    if (colIndex.TryGetValue(fieldNames[d], out int col) && col < parts.Length)
                        float.TryParse(parts[col].Trim(),
                            System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out vals[d]);
                }

                bool firstInStep = true;
                for (int d = 0; d < 6; d++)
                {
                    if (Mathf.Approximately(vals[d], 0f)) continue;

                    StepRow row = new StepRow();
                    row.dof = (DOF)d;
                    row.valueInput = vals[d].ToString("F1");
                    row.durationInput = "1";
                    row.smooth = false;
                    row.waitForPrevious = firstInStep;
                    firstInStep = false;
                    rows.Add(row);
                }
                stepCount++;
            }

            importStatus = $"Imported {stepCount} steps ({rows.Count} rows)";
        }
        catch (System.Exception ex)
        {
            importStatus = $"Error: {ex.Message}";
        }
    }

    // ── Validation ────────────────────────────────────────────────────────────

    void ValidateSetup()
    {
        List<string> problems = new List<string>();

        for (int d = 0; d < 6; d++)
        {
            DOF dof = (DOF)d;
            if (GetJoint(dof) == null)
                problems.Add($"{dofLabels[d]} joint is unassigned");
        }

        for (int a = 0; a < 6; a++)
            for (int b = a + 1; b < 6; b++)
            {
                Transform ta = GetJoint((DOF)a);
                Transform tb = GetJoint((DOF)b);
                if (ta != null && ta == tb)
                    problems.Add($"{dofLabels[a]} and {dofLabels[b]} share the same Transform");
            }

        if (focalSpot == null)
            problems.Add("Focal Spot is unassigned");

        statusText = problems.Count == 0
            ? "Setup OK"
            : "ISSUES: " + string.Join("; ", problems);

        foreach (string p in problems)
            Debug.LogWarning("[DOFSequenceBuilder] " + p);
    }

    // ── View mode ─────────────────────────────────────────────────────────────

    void SetViewMode(int mode, ConeSmear smear)
    {
        foreach (GameObject obj in hiddenObjects)
        {
            if (obj != null)
            {
                MeshRenderer mr = obj.GetComponent<MeshRenderer>();
                if (mr != null && !editorDisabledRenderers.Contains(mr))
                    mr.enabled = true;
            }
        }
        hiddenObjects.Clear();

        MeshRenderer[] allRenderers = FindObjectsOfType<MeshRenderer>(true);
        foreach (MeshRenderer mr in allRenderers)
            if (mr.gameObject.name == "SmearGhost")
                mr.enabled = (mode != 2);

        viewMode = mode;

        if (mode == 1)
        {
            foreach (MeshRenderer mr in allRenderers)
            {
                if (mr.gameObject.name == "SmearGhost") continue;
                if (editorDisabledRenderers.Contains(mr)) continue;
                mr.enabled = false;
                hiddenObjects.Add(mr.gameObject);
            }
        }
    }

    // ── Reset ─────────────────────────────────────────────────────────────────

    void ResetToZero()
    {
        if (playCoroutine != null) StopCoroutine(playCoroutine);
        isPlaying = false;
        statusText = "Reset to zero";

        StartCoroutine(AnimateToAbsolute(inPlaneJoint, Vector3.forward, 90f, 1f, true));
        StartCoroutine(AnimateToAbsolute(cranioCaudalJoint, Vector3.up, 0f, 1f, true));
        StartCoroutine(AnimateToAbsolute(lateralJoint, Vector3.right, 0f, 1f, true));
        StartCoroutine(ResetTranslation(gantryJoint, gantryStartLocal, 1f, true));
        StartCoroutine(ResetTranslation(columnHeightJoint, columnHeightStartLocal, 1f, true));
        StartCoroutine(ResetTranslation(gantryLRJoint, gantryLRStartLocal, 1f, true));
    }

    // ── Playback ──────────────────────────────────────────────────────────────

    IEnumerator PlaySequence()
    {
        do
        {
            List<Coroutine> running = new List<Coroutine>();

            for (int i = 0; i < rows.Count; i++)
            {
                StepRow row = rows[i];
                if (row.waitForPrevious)
                {
                    foreach (var r in running) yield return r;
                    running.Clear();
                }
                running.Add(StartCoroutine(RunStep(row, i + 1, rows.Count)));
            }

            foreach (var r in running) yield return r;

        } while (loop);

        isPlaying = false;
        statusText = "Finished";
    }

    IEnumerator RunStep(StepRow row, int stepNum, int totalSteps)
    {
        Transform joint = GetJoint(row.dof);
        if (joint == null)
        {
            Debug.LogWarning($"[DOFSequenceBuilder] No joint for {dofLabels[(int)row.dof]} — skipped");
            statusText = $"SKIPPED: {dofLabels[(int)row.dof]} has no joint assigned";
            yield break;
        }

        if (!float.TryParse(row.valueInput, out float amount)) amount = 0f;
        if (!float.TryParse(row.durationInput, out float duration)) duration = 1f;
        duration = Mathf.Max(duration, 0.01f);

        statusText = $"Step {stepNum}/{totalSteps}: {dofLabels[(int)row.dof]} +{amount} " +
                     $"({(row.smooth ? "smooth" : "linear")}, {duration}s)";

        if (IsRotational(row.dof))
            yield return StartCoroutine(
                AnimateByAngle(joint, GetLocalAxis(row.dof), amount, duration, row.smooth));
        else
            yield return StartCoroutine(
                AnimateTranslation(joint, GetTranslationDirWorld(row.dof),
                    amount / 100f, duration, row.smooth));
    }

    IEnumerator AnimateByAngle(Transform joint, Vector3 axis,
        float deltaDegrees, float duration, bool smooth)
    {
        if (joint == null) yield break;

        float elapsed = 0f, applied = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            float target = smooth
                ? Mathf.SmoothStep(0, deltaDegrees, t)
                : Mathf.Lerp(0, deltaDegrees, t);
            float delta = target - applied;
            applied = target;
            joint.Rotate(axis, delta, Space.Self);
            yield return null;
        }
        joint.Rotate(axis, deltaDegrees - applied, Space.Self);
    }

    IEnumerator AnimateToAbsolute(Transform joint, Vector3 axis,
        float targetDegrees, float duration, bool smooth)
    {
        if (joint == null) yield break;

        float startDegrees = GetCurrentAngle(joint, axis);
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            float interpolated = smooth
                ? Mathf.SmoothStep(startDegrees, targetDegrees, t)
                : Mathf.Lerp(startDegrees, targetDegrees, t);
            SetAxisAngle(joint, axis, interpolated);
            yield return null;
        }
        SetAxisAngle(joint, axis, targetDegrees);
    }

    IEnumerator AnimateTranslation(Transform joint, Vector3 worldDir,
        float deltaMeters, float duration, bool smooth)
    {
        if (joint == null) yield break;

        Vector3 localDir = ToParentSpace(joint, worldDir);
        float elapsed = 0f, applied = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            float target = smooth
                ? Mathf.SmoothStep(0, deltaMeters, t)
                : Mathf.Lerp(0, deltaMeters, t);
            float delta = target - applied;
            applied = target;
            joint.localPosition += localDir * delta;
            yield return null;
        }
        joint.localPosition += localDir * (deltaMeters - applied);
    }

    IEnumerator ResetTranslation(Transform joint, Vector3 targetLocalPos,
        float duration, bool smooth)
    {
        if (joint == null) yield break;

        Vector3 startPos = joint.localPosition;
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            joint.localPosition = smooth
                ? Vector3.Lerp(startPos, targetLocalPos, Mathf.SmoothStep(0, 1, t))
                : Vector3.Lerp(startPos, targetLocalPos, t);
            yield return null;
        }
        joint.localPosition = targetLocalPos;
    }

    float GetCurrentAngle(Transform joint, Vector3 axis)
    {
        float angle;
        if (axis == Vector3.right) angle = joint.localEulerAngles.x;
        else if (axis == Vector3.up) angle = joint.localEulerAngles.y;
        else angle = joint.localEulerAngles.z;
        return angle > 180f ? angle - 360f : angle;
    }

    void SetAxisAngle(Transform joint, Vector3 axis, float degrees)
    {
        Vector3 euler = joint.localEulerAngles;
        if (axis == Vector3.right) euler.x = degrees;
        else if (axis == Vector3.up) euler.y = degrees;
        else euler.z = degrees;
        joint.localEulerAngles = euler;
    }

    // ── Export ────────────────────────────────────────────────────────────────

    Dictionary<DOF, Vector3> groupStartLocal = new Dictionary<DOF, Vector3>();
    Dictionary<DOF, float> groupStartAngle = new Dictionary<DOF, float>();

    void CaptureGroupStartLocal()
    {
        if (gantryJoint) groupStartLocal[DOF.Gantry] = gantryJoint.localPosition;
        if (columnHeightJoint) groupStartLocal[DOF.ColumnHeight] = columnHeightJoint.localPosition;
        if (gantryLRJoint) groupStartLocal[DOF.GantryLR] = gantryLRJoint.localPosition;
    }

    void CaptureGroupStartAngle()
    {
        if (lateralJoint) groupStartAngle[DOF.Lateral] = GetCurrentAngle(lateralJoint, Vector3.right);
        if (cranioCaudalJoint) groupStartAngle[DOF.CranioCaudal] = GetCurrentAngle(cranioCaudalJoint, Vector3.up);
        if (inPlaneJoint) groupStartAngle[DOF.InPlane] = GetCurrentAngle(inPlaneJoint, Vector3.forward);
    }

    void ApplyRowAtFraction(StepRow row, float t)
    {
        Transform joint = GetJoint(row.dof);
        if (joint == null) return;

        if (!float.TryParse(row.valueInput, out float amount)) amount = 0f;

        if (IsRotational(row.dof))
        {
            Vector3 axis = GetLocalAxis(row.dof);
            float start = groupStartAngle.ContainsKey(row.dof) ? groupStartAngle[row.dof] : 0f;
            SetAxisAngle(joint, axis, start + amount * t);
        }
        else
        {
            Vector3 localDir = ToParentSpace(joint, GetTranslationDirWorld(row.dof));
            Vector3 start = groupStartLocal.ContainsKey(row.dof)
                ? groupStartLocal[row.dof]
                : joint.localPosition;
            joint.localPosition = start + localDir * ((amount / 100f) * t);
        }
    }

    IEnumerator ExportSourcePositions()
    {
        statusText = "Calculating source positions...";
        yield return null;

        Quaternion savedInPlane = inPlaneJoint ? inPlaneJoint.localRotation : Quaternion.identity;
        Quaternion savedCrCd = cranioCaudalJoint ? cranioCaudalJoint.localRotation : Quaternion.identity;
        Quaternion savedLat = lateralJoint ? lateralJoint.localRotation : Quaternion.identity;
        Vector3 savedGantry = gantryJoint ? gantryJoint.localPosition : Vector3.zero;
        Vector3 savedColumn = columnHeightJoint ? columnHeightJoint.localPosition : Vector3.zero;
        Vector3 savedGantryLR = gantryLRJoint ? gantryLRJoint.localPosition : Vector3.zero;

        var groups = new List<List<StepRow>>();
        List<StepRow> current = null;
        foreach (StepRow row in rows)
        {
            if (row.waitForPrevious || current == null)
            {
                current = new List<StepRow>();
                groups.Add(current);
            }
            current.Add(row);
        }

        var groupLengths = new List<float>();
        float totalLength = 0f;

        foreach (var group in groups)
        {
            float groupLen = 0f;
            foreach (StepRow row in group)
            {
                float.TryParse(row.valueInput, out float amount);
                float len;
                if (IsRotational(row.dof))
                {
                    Transform j = GetJoint(row.dof);
                    float radius = (j != null && focalSpot != null)
                        ? Vector3.Distance(j.position, focalSpot.position) : 1f;
                    len = radius * Mathf.Abs(amount) * Mathf.Deg2Rad;
                }
                else
                {
                    len = Mathf.Abs(amount / 100f);
                }
                groupLen = Mathf.Max(groupLen, len);
            }
            groupLengths.Add(groupLen);
            totalLength += groupLen;
        }

        if (totalLength < 0.0001f)
        {
            statusText = "ERROR: total path length is zero — nothing to export";
            yield break;
        }

        float stepSize = totalLength / Mathf.Max(1, numProjections - 1);
        var sourcePositions = new List<Vector3>();
        float distanceCovered = 0f;
        int projIndex = 0;

        for (int g = 0; g < groups.Count && projIndex < numProjections; g++)
        {
            var group = groups[g];
            float groupLen = groupLengths[g];

            CaptureGroupStartLocal();
            CaptureGroupStartAngle();

            while (projIndex < numProjections)
            {
                float targetDist = projIndex * stepSize;
                if (targetDist > distanceCovered + groupLen + 0.0001f) break;

                float localDist = targetDist - distanceCovered;
                float t = groupLen > 0.0001f ? Mathf.Clamp01(localDist / groupLen) : 1f;

                foreach (StepRow row in group)
                    ApplyRowAtFraction(row, t);

                yield return null;

                sourcePositions.Add(focalSpot.position);
                projIndex++;
            }

            foreach (StepRow row in group)
                ApplyRowAtFraction(row, 1f);

            yield return null;
            distanceCovered += groupLen;
        }

        while (sourcePositions.Count < numProjections && sourcePositions.Count > 0)
            sourcePositions.Add(sourcePositions[sourcePositions.Count - 1]);

        if (inPlaneJoint) inPlaneJoint.localRotation = savedInPlane;
        if (cranioCaudalJoint) cranioCaudalJoint.localRotation = savedCrCd;
        if (lateralJoint) lateralJoint.localRotation = savedLat;
        if (gantryJoint) gantryJoint.localPosition = savedGantry;
        if (columnHeightJoint) columnHeightJoint.localPosition = savedColumn;
        if (gantryLRJoint) gantryLRJoint.localPosition = savedGantryLR;

        yield return null;

        string path = Path.Combine(Application.dataPath, "source_positions.csv");
        using (StreamWriter sw = new StreamWriter(path))
        {
            sw.WriteLine("# units: Unity world units");
            sw.WriteLine("# coordinate_convention: Unity left-handed, Y-up");
            sw.WriteLine($"# n_projections: {sourcePositions.Count}");
            sw.WriteLine($"# total_path_length: {totalLength:F4}");
            sw.WriteLine("index,src_x,src_y,src_z");

            for (int i = 0; i < sourcePositions.Count; i++)
            {
                Vector3 p = sourcePositions[i];
                sw.WriteLine($"{i},{p.x:F6},{p.y:F6},{p.z:F6}");
            }
        }

        statusText = $"Exported {sourcePositions.Count} projections to Assets/source_positions.csv";
    }
}
