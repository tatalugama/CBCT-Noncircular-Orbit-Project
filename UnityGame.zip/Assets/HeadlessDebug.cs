using UnityEngine;

public class HeadlessModeInit : MonoBehaviour
{
    void Awake()
    {
        if (!Application.isBatchMode) return;

        foreach (var s in FindObjectsOfType<KeyedJointRotator>()) s.enabled = false;
        foreach (var s in FindObjectsOfType<LinearAxisMover>()) s.enabled = false;
        foreach (var s in FindObjectsOfType<CameraOrbit>()) s.enabled = false;
        foreach (var s in FindObjectsOfType<ArmCollision>()) s.enabled = false;
        foreach (var s in FindObjectsOfType<DOFSequenceBuilder>()) s.enabled = false;
        foreach (var s in FindObjectsOfType<ConeSmear>()) s.enabled = false;

        Debug.Log("[HeadlessModeInit] interactive scripts disabled");
    }
}