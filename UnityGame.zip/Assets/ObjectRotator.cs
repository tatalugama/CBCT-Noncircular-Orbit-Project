using UnityEngine;
using System.Collections;
using UnityEngine.InputSystem;

public class ObjectRotator : MonoBehaviour
{
    private float _sensitivity;
    private Vector3 _mouseReference;
    private Vector3 _mouseOffset;
    private Vector3 _rotation;
    private bool _isRotating;

    void Start()
    {
        _sensitivity = 0.4f;
        _rotation = Vector3.zero;
    }

    void Update()
    {
        if (_isRotating)
        {
            _mouseOffset = (Vector3)Mouse.current.position.ReadValue() - _mouseReference;
            _rotation.y = -(_mouseOffset.x + _mouseOffset.y) * _sensitivity;
            transform.Rotate(_rotation);
            _mouseReference = Mouse.current.position.ReadValue();
        }
    }

    void OnMouseDown()
    {
        _isRotating = true;
        _mouseReference = Mouse.current.position.ReadValue();
    }

    void OnMouseUp()
    {
        _isRotating = false;
    }
}