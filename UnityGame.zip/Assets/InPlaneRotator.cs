using UnityEngine;
using UnityEngine.InputSystem;

public class DetectorInPlane : MonoBehaviour
{
    [SerializeField] float arrowSensitivity = 60f;

    void Update()
    {
        if (Keyboard.current[Key.LeftArrow].isPressed)
        {
            transform.Rotate(Vector3.up, -arrowSensitivity * Time.deltaTime, Space.Self);
        }
        if (Keyboard.current[Key.RightArrow].isPressed)
        {
            transform.Rotate(Vector3.up, arrowSensitivity * Time.deltaTime, Space.Self);
        }
    }
}