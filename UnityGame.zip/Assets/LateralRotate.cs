using UnityEngine;
using UnityEngine.InputSystem;

public class LateralRotate : MonoBehaviour
{
    [SerializeField] float arrowSensitivity = 60f;

    void Update()
    {
        if (Keyboard.current[Key.Digit3].isPressed && Keyboard.current[Key.LeftArrow].isPressed)
        {
            transform.Rotate(Vector3.forward, -arrowSensitivity * Time.deltaTime, Space.Self);
        }
        if (Keyboard.current[Key.Digit3].isPressed && Keyboard.current[Key.RightArrow].isPressed)
        {
            transform.Rotate(Vector3.forward, arrowSensitivity * Time.deltaTime, Space.Self);
        }
    }
}