using UnityEngine;
using UnityEngine.InputSystem;

public class CameraOrbit : MonoBehaviour
{
    [SerializeField] float sensitivity = 0.3f;
    [SerializeField] Transform target;

    Vector2 rotation;

    void Start()
    {
        rotation.x = transform.eulerAngles.y;
        rotation.y = transform.eulerAngles.x;
    }

    void Update()
    {
        if (Mouse.current.rightButton.isPressed)
        {
            Vector2 mouseDelta = Mouse.current.delta.ReadValue();
            rotation.x += mouseDelta.x * sensitivity;
            rotation.y -= mouseDelta.y * sensitivity;
            rotation.y = Mathf.Clamp(rotation.y, -80f, 80f);

            float distance = Vector3.Distance(transform.position, target.position);
            Quaternion rot = Quaternion.Euler(rotation.y, rotation.x, 0);
            transform.position = target.position - rot * Vector3.forward * distance;
            transform.rotation = rot;
        }
    }
}