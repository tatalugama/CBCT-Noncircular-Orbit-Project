[System.Serializable]
public class SequenceStep
{
    public enum RotationType { InPlane, CranioCaudal }
    public RotationType rotationType;
    public float degrees;
    public float duration = 1f;
}