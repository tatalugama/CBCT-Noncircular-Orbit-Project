using UnityEngine;

public class ArmCollision : MonoBehaviour
{
    Renderer rend;
    Material originalMaterial;
    [SerializeField] Material redMaterial;

    bool justStarted = true;

    void Start()
    {
        rend = GetComponent<Renderer>();
        originalMaterial = rend.material;
        Invoke(nameof(ClearStartFlag), 0.1f);
    }

    void ClearStartFlag()
    {
        justStarted = false;
    }

    void OnTriggerEnter(Collider other)
    {
        if (justStarted) return;
        rend.material = redMaterial;
    }

    void OnTriggerExit(Collider other)
    {
        rend.material = originalMaterial;
    }
}