using UnityEngine;

public class RotationInputUI : MonoBehaviour
{
    [Header("Joint References")]
    [SerializeField] Transform inPlaneJoint;
    [SerializeField] Transform cranioCaudalJoint;
    [SerializeField] Transform lateralJoint;

    [Header("Limits")]
    [SerializeField] float cranioCaudalMin = -45f;
    [SerializeField] float cranioCaudalMax = 45f;
    [SerializeField] float inPlaneMin = -180f;
    [SerializeField] float inPlaneMax = 180f;
    [SerializeField] float lateralMin = -180f;
    [SerializeField] float lateralMax = 180f;

    [Header("Continuous Rotation Speed")]
    [SerializeField] float continuousSpeed = 60f; // degrees per second

    string inPlaneInput = "0";
    string cranioCaudalInput = "0";
    string lateralInput = "0";

    bool inPlaneContinuous = false;
    bool cranioCaudalContinuous = false;
    bool lateralContinuous = false;

    void OnGUI()
    {
        GUI.Box(new Rect(10, 10, 280, 220), "C-Arm Rotation Control");

        GUI.Label(new Rect(20, 40, 140, 20), "In-Plane (� or R):");
        inPlaneInput = GUI.TextField(new Rect(170, 40, 100, 20), inPlaneInput);

        GUI.Label(new Rect(20, 70, 140, 20), "Cranio/Caudal (� or R):");
        cranioCaudalInput = GUI.TextField(new Rect(170, 70, 100, 20), cranioCaudalInput);

        GUI.Label(new Rect(20, 100, 140, 20), "Lateral (� or R):");
        lateralInput = GUI.TextField(new Rect(170, 100, 100, 20), lateralInput);

        if (GUI.Button(new Rect(20, 130, 250, 30), "Apply"))
        {
            ApplyInput(inPlaneInput, out inPlaneContinuous);
            ApplyInput(cranioCaudalInput, out cranioCaudalContinuous);
            ApplyInput(lateralInput, out lateralContinuous);
        }

        string status = $"InPlane: {(inPlaneContinuous ? "Rotating" : "Fixed")}\n" +
                        $"CranioCaudal: {(cranioCaudalContinuous ? "Rotating" : "Fixed")}\n" +
                        $"Lateral: {(lateralContinuous ? "Rotating" : "Fixed")}";
        GUI.Label(new Rect(20, 165, 250, 60), status);
    }

    void ApplyInput(string input, out bool isContinuous)
    {
        isContinuous = input.Trim().ToUpper() == "R";
        // If it's a fixed value, the actual setting happens in Update via SetFixedAngle
    }

    void Update()
    {
        UpdateJoint(inPlaneJoint, inPlaneInput, ref inPlaneContinuous, Axis.Forward, inPlaneMin, inPlaneMax);
        UpdateJoint(cranioCaudalJoint, cranioCaudalInput, ref cranioCaudalContinuous, Axis.Up, cranioCaudalMin, cranioCaudalMax);
        UpdateJoint(lateralJoint, lateralInput, ref lateralContinuous, Axis.Right, lateralMin, lateralMax);
    }

    enum Axis { Right, Up, Forward }

    void UpdateJoint(Transform joint, string input, ref bool isContinuous, Axis axis, float min, float max)
    {
        if (joint == null) return;

        bool wantsContinuous = input.Trim().ToUpper() == "R";
        isContinuous = wantsContinuous;

        if (wantsContinuous)
        {
            // Rotate continuously - ignores clamp since it's meant to spin freely
            RotateOnAxis(joint, axis, continuousSpeed * Time.deltaTime);
        }
        else if (float.TryParse(input, out float degrees))
        {
            degrees = Mathf.Clamp(degrees, min, max);
            SetAxisAngle(joint, axis, degrees);
        }
    }

    void RotateOnAxis(Transform joint, Axis axis, float delta)
    {
        Vector3 dir = Vector3.zero;
        switch (axis)
        {
            case Axis.Right: dir = Vector3.right; break;
            case Axis.Up: dir = Vector3.up; break;
            case Axis.Forward: dir = Vector3.forward; break;
        }
        joint.Rotate(dir, delta, Space.Self);
    }

    void SetAxisAngle(Transform joint, Axis axis, float degrees)
    {
        Vector3 euler = Vector3.zero;
        switch (axis)
        {
            case Axis.Right: euler = new Vector3(degrees, 0, 0); break;
            case Axis.Up: euler = new Vector3(0, degrees, 0); break;
            case Axis.Forward: euler = new Vector3(0, 0, degrees); break;
        }
        joint.localEulerAngles = euler;
    }
}