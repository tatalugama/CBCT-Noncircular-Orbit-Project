using UnityEngine;
using UnityEngine.InputSystem;

public class CranioCaudalRotator : MonoBehaviour
{
    [SerializeField] float sensitivity = 0.3f;
    [SerializeField] float arrowSensitivity = 60f;

    void Update()
    {
        if (Keyboard.current[Key.Digit1].isPressed)
        {
            Vector2 mouseDelta = Mouse.current.delta.ReadValue();
            float rotation = (mouseDelta.x + mouseDelta.y) * sensitivity;
            transform.Rotate(Vector3.right, rotation, Space.Self);
        }

        if (Keyboard.current[Key.UpArrow].isPressed)
        {
            transform.Rotate(Vector3.right, arrowSensitivity * Time.deltaTime, Space.Self);
        }
        if (Keyboard.current[Key.DownArrow].isPressed)
        {
            transform.Rotate(Vector3.right, -arrowSensitivity * Time.deltaTime, Space.Self);
        }
    }
}