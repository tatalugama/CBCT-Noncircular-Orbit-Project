﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

public class BatchRunner : MonoBehaviour
{
    [SerializeField] OrbitScorer scorer;

    [Tooltip("Optional: folder for one trajectory CSV per candidate, used by the " +
             "Tuy completeness analysis. Leave empty to skip. Overridden by -trajdir.")]
    [SerializeField] string trajectoryFolder = "";

    [System.Serializable] class Candidate { public float[] p; }
    [System.Serializable] class CandidateBatch { public Candidate[] candidates; }

    [System.Serializable]
    class ResultEntry
    {
        public float fitness;
        public float collisionPenalty;
        public float centeringPenalty;
        public float sampling;
        public int sampledVoxels;
        public int roiVoxels;
        public float maxDepthCm;
        public float maxMissCm;
        public int touchingProjections;
    }

    [System.Serializable] class ResultBatch { public ResultEntry[] results; }

    void Start()
    {
        string inPath = Arg("-in");
        string outPath = Arg("-out");
        string trajArg = Arg("-trajdir");

        if (string.IsNullOrEmpty(inPath) || string.IsNullOrEmpty(outPath))
        {
            Debug.Log("[BatchRunner] no -in/-out args — idle");
            enabled = false;
            return;
        }

        if (scorer == null)
        {
            Debug.LogError("[BatchRunner] OrbitScorer not assigned");
            Quit(1);
            return;
        }

        if (!string.IsNullOrEmpty(trajArg))
            trajectoryFolder = trajArg;

        StartCoroutine(Run(inPath, outPath));
    }

    IEnumerator Run(string inPath, string outPath)
    {
        yield return null;

        CandidateBatch input;
        try
        {
            input = JsonUtility.FromJson<CandidateBatch>(File.ReadAllText(inPath));
        }
        catch (System.Exception e)
        {
            Debug.LogError($"[BatchRunner] cannot read {inPath}: {e.Message}");
            Quit(1); yield break;
        }

        if (input == null || input.candidates == null || input.candidates.Length == 0)
        {
            Debug.LogError("[BatchRunner] no candidates in input");
            Quit(1); yield break;
        }

        bool writeTraj = !string.IsNullOrEmpty(trajectoryFolder);
        if (writeTraj)
        {
            try { Directory.CreateDirectory(trajectoryFolder); }
            catch (System.Exception e)
            {
                Debug.LogWarning($"[BatchRunner] cannot create '{trajectoryFolder}': " +
                                 $"{e.Message} — skipping trajectories");
                writeTraj = false;
            }
        }

        Debug.Log($"[BatchRunner] scoring {input.candidates.Length} candidates..." +
                  (writeTraj ? $" (trajectories -> '{trajectoryFolder}')" : ""));

        var sw = System.Diagnostics.Stopwatch.StartNew();

        var output = new ResultBatch();
        output.results = new ResultEntry[input.candidates.Length];

        for (int i = 0; i < input.candidates.Length; i++)
        {
            float[] p = input.candidates[i].p;

            OrbitScorer.Result r = scorer.Score(p);
            output.results[i] = new ResultEntry
            {
                fitness = r.fitness,
                collisionPenalty = r.collisionPenalty,
                centeringPenalty = r.centeringPenalty,
                sampling = r.samplingReward,
                sampledVoxels = r.sampledVoxels,
                roiVoxels = r.roiVoxels,
                maxDepthCm = r.maxDepthCm,
                maxMissCm = r.maxMissM * 100f,
                touchingProjections = r.touchingProjections,
            };

            if (writeTraj) WriteTrajectory(trajectoryFolder, i, p);
        }

        sw.Stop();

        try
        {
            File.WriteAllText(outPath, JsonUtility.ToJson(output));
        }
        catch (System.Exception e)
        {
            Debug.LogError($"[BatchRunner] cannot write {outPath}: {e.Message}");
            Quit(1); yield break;
        }

        Debug.Log($"[BatchRunner] scored {input.candidates.Length} candidates in " +
                  $"{sw.ElapsedMilliseconds}ms");
        Quit(0);
    }

    void WriteTrajectory(string dir, int index, float[] p)
    {
        List<OrbitScorer.Pose> traj = scorer.RecordTrajectory(p);

        var ci = CultureInfo.InvariantCulture;
        var sb = new StringBuilder();

        // Metadata the Tuy analysis needs, as comments so pandas skips them
        Vector3 h = scorer.HeadPosition;
        sb.AppendLine($"# head_unity={h.x.ToString("F6", ci)}," +
                                   $"{h.y.ToString("F6", ci)}," +
                                   $"{h.z.ToString("F6", ci)}");
        sb.AppendLine($"# roi_radius_m={scorer.RoiRadiusM.ToString("F6", ci)}");
        sb.AppendLine($"# projections={traj.Count}");

        sb.AppendLine("projection,src_x,src_y,src_z,det_x,det_y,det_z," +
                      "u_x,u_y,u_z,v_x,v_y,v_z");

        for (int i = 0; i < traj.Count; i++)
        {
            OrbitScorer.Pose q = traj[i];
            sb.AppendLine(string.Join(",", new string[]
            {
                i.ToString(ci),
                q.source.x.ToString("F6", ci),   q.source.y.ToString("F6", ci),   q.source.z.ToString("F6", ci),
                q.detector.x.ToString("F6", ci), q.detector.y.ToString("F6", ci), q.detector.z.ToString("F6", ci),
                q.right.x.ToString("F6", ci),    q.right.y.ToString("F6", ci),    q.right.z.ToString("F6", ci),
                q.up.x.ToString("F6", ci),       q.up.y.ToString("F6", ci),       q.up.z.ToString("F6", ci),
            }));
        }

        try
        {
            File.WriteAllText(Path.Combine(dir, $"traj_{index:D3}.csv"), sb.ToString());
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"[BatchRunner] trajectory {index} not written: {e.Message}");
        }
    }

    static string Arg(string name)
    {
        string[] a = System.Environment.GetCommandLineArgs();
        for (int i = 0; i < a.Length - 1; i++)
            if (a[i] == name) return a[i + 1];
        return null;
    }

    static void Quit(int code)
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit(code);
#endif
    }
}