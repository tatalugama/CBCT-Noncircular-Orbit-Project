﻿using UnityEngine;
using System.Collections.Generic;

public class OrbitScorer : MonoBehaviour
{
    /// <summary>How CranioCaudal moves between step waypoints.</summary>
    public enum CrCdInterp
    {
        Linear,      // constant velocity, sharp reversals — sawtooth (Reynolds et al.)
        SmoothStep,  // eases in AND out of every waypoint, including zero-crossings
        Sinusoidal,  // Catmull-Rom: continuous velocity through waypoints — true sine
    }

    [Header("Joints — order matches the 6 DOF")]
    [SerializeField] Transform lateralJoint;
    [SerializeField] Transform cranioCaudalJoint;
    [SerializeField] Transform inPlaneJoint;
    [SerializeField] Transform gantryJoint;
    [SerializeField] Transform columnHeightJoint;
    [SerializeField] Transform gantryLRJoint;

    [Header("Translation directions (world space)")]
    [SerializeField] Vector3 gantryDir = Vector3.right;
    [SerializeField] Vector3 columnHeightDir = Vector3.up;
    [SerializeField] Vector3 gantryLRDir = Vector3.forward;

    [Header("Beam")]
    [SerializeField] Transform focalSpot;
    [SerializeField] Transform detectorFace;
    [SerializeField] MeshRenderer coneMesh;

    [Header("Target")]
    [SerializeField] Transform head;
    [SerializeField] Transform[] armRoots;
    [SerializeField] string obstacleTag = "Obstacle";

    [Header("Discretization")]
    [SerializeField] int projections = 300;
    [SerializeField] float roiRadiusM = 0.15f;
    [SerializeField] float voxelSizeM = 0.01f;
    [SerializeField] int samplingThreshold = 5;
    [SerializeField] int raysPerSide = 10;

    [Header("Motion profile")]
    [Tooltip("CranioCaudal only. Linear = sawtooth. Sinusoidal = Catmull-Rom " +
             "through the same waypoints, giving a true sine. SmoothStep eases " +
             "in and out of EVERY waypoint, so it flattens at zero-crossings " +
             "where a real sine is fastest. Lateral is always linear.")]
    [SerializeField] CrCdInterp cranioCaudalInterp = CrCdInterp.Sinusoidal;

    [Header("Joint limits")]
    [SerializeField] float lateralMaxPerStepDeg = 180f;
    [SerializeField] float inPlaneMaxDeg = 60f;
    [SerializeField] float cranioCaudalMaxDeg = 45f;
    [SerializeField] float translationMaxCm = 20f;

    [Header("Weights")]
    [Tooltip("Flat penalty for ANY overlap in a projection, however shallow")]
    [SerializeField] float binaryCollisionWeight = 20f;
    [SerializeField] float lightCollisionWeight = 10f;
    [SerializeField] float harshCollisionWeight = 200f;
    [SerializeField] float samplingWeight = 1f;

    [Header("Debug")]
    [SerializeField] bool verbose = false;

    // ── Public accessors (used by BatchRunner for the trajectory export) ──────

    public Vector3 HeadPosition => head != null ? head.position : Vector3.zero;
    public float RoiRadiusM => roiRadiusM;

    public struct Result
    {
        public float fitness;
        public float collisionPenalty;
        public float centeringPenalty;
        public float samplingReward;
        public int sampledVoxels;
        public int roiVoxels;
        public float maxDepthCm;
        public float maxMissM;
        public int touchingProjections;
    }

    /// <summary>Full acquisition geometry at one projection.</summary>
    public struct Pose
    {
        public Vector3 source;
        public Vector3 detector;
        public Vector3 right;
        public Vector3 up;
    }

    const int NUM_STEPS = 8;
    const int NUM_DOF = 6;
    const float SEVERE_DEPTH_CM = 5f;

    int[] counts;
    bool[] isRoi;
    int nx, ny, nz, roiVoxelCount;
    Vector3 gridOrigin;

    List<Collider> armColliders = new List<Collider>();
    List<Collider> obstacleColliders = new List<Collider>();

    Quaternion lateralHome, cranioCaudalHome, inPlaneHome;
    Vector3 gantryHome, columnHome, gantryLRHome;

    bool ready = false;

    void Awake()
    {
        CacheHome();
        BuildGrid();
        CollectColliders();
        ready = true;

        Debug.Log($"[OrbitScorer] CranioCaudal motion profile: {cranioCaudalInterp} " +
                  $"(lateral is always linear)");
    }

    void CacheHome()
    {
        if (lateralJoint) lateralHome = lateralJoint.localRotation;
        if (cranioCaudalJoint) cranioCaudalHome = cranioCaudalJoint.localRotation;
        if (inPlaneJoint) inPlaneHome = inPlaneJoint.localRotation;
        if (gantryJoint) gantryHome = gantryJoint.localPosition;
        if (columnHeightJoint) columnHome = columnHeightJoint.localPosition;
        if (gantryLRJoint) gantryLRHome = gantryLRJoint.localPosition;
    }

    void BuildGrid()
    {
        if (head == null) { Debug.LogError("[OrbitScorer] head not assigned"); return; }

        float side = roiRadiusM * 2f;
        int n = Mathf.Max(1, Mathf.CeilToInt(side / voxelSizeM));
        nx = ny = nz = n;

        gridOrigin = head.position - Vector3.one * roiRadiusM;
        counts = new int[n * n * n];
        isRoi = new bool[n * n * n];
        roiVoxelCount = 0;

        for (int z = 0; z < nz; z++)
            for (int y = 0; y < ny; y++)
                for (int x = 0; x < nx; x++)
                {
                    Vector3 c = gridOrigin + new Vector3(x + 0.5f, y + 0.5f, z + 0.5f) * voxelSizeM;
                    bool inside = Vector3.Distance(c, head.position) <= roiRadiusM;
                    isRoi[Idx(x, y, z)] = inside;
                    if (inside) roiVoxelCount++;
                }

        Debug.Log($"[OrbitScorer] grid {n}^3 at {voxelSizeM * 100f:F1}cm, " +
                  $"ROI = {roiVoxelCount} voxels within {roiRadiusM * 100f:F0}cm of head");

        if (roiVoxelCount == 0)
            Debug.LogError("[OrbitScorer] ROI is empty — roiRadiusM smaller than one voxel");
    }

    void CollectColliders()
    {
        armColliders.Clear();
        foreach (Transform root in armRoots)
        {
            if (root == null) continue;
            foreach (Collider c in root.GetComponentsInChildren<Collider>())
            {
                if (c.isTrigger) continue;
                if (!armColliders.Contains(c)) armColliders.Add(c);
            }
        }

        for (int i = 0; i < armColliders.Count; i++)
            for (int j = i + 1; j < armColliders.Count; j++)
                Physics.IgnoreCollision(armColliders[i], armColliders[j], true);

        obstacleColliders.Clear();
        foreach (GameObject o in GameObject.FindGameObjectsWithTag(obstacleTag))
            obstacleColliders.AddRange(o.GetComponents<Collider>());

        Debug.Log($"[OrbitScorer] {armColliders.Count} arm colliders, " +
                  $"{obstacleColliders.Count} obstacle colliders");

        foreach (Collider c in armColliders) LogCollider("arm", c);
        foreach (Collider c in obstacleColliders) LogCollider("obstacle", c);
    }

    static void LogCollider(string role, Collider c)
    {
        string warn = "";
        if (c is MeshCollider mc && !mc.convex)
            warn = "  <-- NON-CONVEX: ComputePenetration will not detect this";

        string path = c.name;
        Transform t = c.transform;
        while (t.parent != null) { t = t.parent; path = t.name + "/" + path; }
        Debug.Log($"[OrbitScorer]   {role}: {path} — {c.GetType().Name}{warn}");
    }

    public Result Score(float[] p)
    {
        var r = new Result();
        if (!ready || p == null || p.Length != NUM_STEPS * NUM_DOF)
        {
            Debug.LogError($"[OrbitScorer] bad input (expected {NUM_STEPS * NUM_DOF})");
            return r;
        }

        System.Array.Clear(counts, 0, counts.Length);

        float[,] cum = BuildCumulative(p);

        float collision = 0f;
        int touching = 0;

        for (int i = 0; i < projections; i++)
        {
            float u = projections > 1 ? (float)i / (projections - 1) : 1f;
            ApplyPose(cum, u);
            Physics.SyncTransforms();

            float depthCm = DeepestPenetrationCm(out bool overlapping);
            if (depthCm > r.maxDepthCm) r.maxDepthCm = depthCm;

            if (overlapping)
            {
                touching++;
                collision += binaryCollisionWeight;
                collision += depthCm < SEVERE_DEPTH_CM
                    ? lightCollisionWeight * depthCm
                    : harshCollisionWeight * depthCm * depthCm;
            }

            CastBeam();
        }

        int sampled = 0;
        for (int i = 0; i < counts.Length; i++)
            if (isRoi[i] && counts[i] >= samplingThreshold) sampled++;

        RestoreHome();

        r.collisionPenalty = collision;
        r.centeringPenalty = 0f;
        r.samplingReward = samplingWeight * sampled;
        r.sampledVoxels = sampled;
        r.roiVoxels = roiVoxelCount;
        r.touchingProjections = touching;
        r.fitness = r.samplingReward - r.collisionPenalty;

        if (verbose)
            Debug.Log($"[OrbitScorer] fitness={r.fitness:F0}  " +
                      $"sampling={r.samplingReward:F0} ({sampled}/{roiVoxelCount})  " +
                      $"collision={r.collisionPenalty:F0} " +
                      $"(touching {touching}/{projections}, max {r.maxDepthCm:F2}cm)");

        return r;
    }

    /// <summary>
    /// Replay an orbit and record the geometry at every projection, without
    /// scoring. This is what the Tuy completeness analysis consumes.
    /// </summary>
    public List<Pose> RecordTrajectory(float[] p)
    {
        var traj = new List<Pose>();
        if (!ready || p == null || p.Length != NUM_STEPS * NUM_DOF) return traj;

        float[,] cum = BuildCumulative(p);

        for (int i = 0; i < projections; i++)
        {
            float u = projections > 1 ? (float)i / (projections - 1) : 1f;
            ApplyPose(cum, u);
            Physics.SyncTransforms();

            traj.Add(new Pose
            {
                source = focalSpot ? focalSpot.position : Vector3.zero,
                detector = detectorFace ? detectorFace.position : Vector3.zero,
                right = detectorFace ? detectorFace.right : Vector3.right,
                up = detectorFace ? detectorFace.up : Vector3.up,
            });
        }

        RestoreHome();
        return traj;
    }

    float[,] BuildCumulative(float[] p)
    {
        var cum = new float[NUM_STEPS + 1, NUM_DOF];
        for (int s = 0; s < NUM_STEPS; s++)
            for (int d = 0; d < NUM_DOF; d++)
                cum[s + 1, d] = cum[s, d] + p[s * NUM_DOF + d];
        return cum;
    }

    // ── Interpolation ─────────────────────────────────────────────────────────

    /// <summary>
    /// CranioCaudal position at segment s, fraction t, under the selected profile.
    /// Every profile passes through the same waypoints — only the path between
    /// them differs, which is exactly the sawtooth-vs-sinusoid distinction.
    /// </summary>
    float InterpCrCd(float[,] cum, int s, float t)
    {
        float p1 = cum[s, 1];
        float p2 = cum[s + 1, 1];

        switch (cranioCaudalInterp)
        {
            case CrCdInterp.Linear:
                return Mathf.Lerp(p1, p2, t);

            case CrCdInterp.SmoothStep:
                return Mathf.SmoothStep(p1, p2, t);

            case CrCdInterp.Sinusoidal:
            default:
                {
                    // Catmull-Rom. Velocity at each waypoint is set from its
                    // neighbours rather than forced to zero, so peaks round off
                    // while zero-crossings stay fast — a genuine sine through
                    // sine-sampled waypoints.
                    float p0 = cum[Mathf.Max(s - 1, 0), 1];
                    float p3 = cum[Mathf.Min(s + 2, NUM_STEPS), 1];

                    float t2 = t * t;
                    float t3 = t2 * t;

                    return 0.5f * ((2f * p1)
                                 + (-p0 + p2) * t
                                 + (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2
                                 + (-p0 + 3f * p1 - 3f * p2 + p3) * t3);
                }
        }
    }

    void ApplyPose(float[,] cum, float u)
    {
        float x = Mathf.Clamp(u * NUM_STEPS, 0f, NUM_STEPS);
        int s = Mathf.Min(Mathf.FloorToInt(x), NUM_STEPS - 1);
        float frac = x - s;

        // Lateral and everything else stay linear — constant gantry velocity,
        // which is what the machine actually does.
        float lat = Mathf.Lerp(cum[s, 0], cum[s + 1, 0], frac);
        float inp = Mathf.Lerp(cum[s, 2], cum[s + 1, 2], frac);
        float gan = Mathf.Lerp(cum[s, 3], cum[s + 1, 3], frac);
        float col = Mathf.Lerp(cum[s, 4], cum[s + 1, 4], frac);
        float glr = Mathf.Lerp(cum[s, 5], cum[s + 1, 5], frac);

        // CranioCaudal uses the selected motion profile
        float crc = InterpCrCd(cum, s, frac);

        if (lateralJoint)
            lateralJoint.localRotation =
                lateralHome * Quaternion.AngleAxis(lat, Vector3.right);
        if (cranioCaudalJoint)
            cranioCaudalJoint.localRotation =
                cranioCaudalHome * Quaternion.AngleAxis(crc, Vector3.up);
        if (inPlaneJoint)
            inPlaneJoint.localRotation =
                inPlaneHome * Quaternion.AngleAxis(inp, Vector3.forward);

        // Reset all translation joints to home first, then add each contribution.
        // This is correct when two DOF share a Transform (ColumnHeight and GantryLR
        // live on the same GameObject) — a straight assignment would let the second
        // write silently discard the first.
        if (gantryJoint) gantryJoint.localPosition = gantryHome;
        if (columnHeightJoint) columnHeightJoint.localPosition = columnHome;
        if (gantryLRJoint) gantryLRJoint.localPosition = gantryLRHome;

        if (gantryJoint)
            gantryJoint.localPosition += ToLocal(gantryJoint, gantryDir) * (gan / 100f);
        if (columnHeightJoint)
            columnHeightJoint.localPosition += ToLocal(columnHeightJoint, columnHeightDir) * (col / 100f);
        if (gantryLRJoint)
            gantryLRJoint.localPosition += ToLocal(gantryLRJoint, gantryLRDir) * (glr / 100f);
    }

    void RestoreHome()
    {
        if (lateralJoint) lateralJoint.localRotation = lateralHome;
        if (cranioCaudalJoint) cranioCaudalJoint.localRotation = cranioCaudalHome;
        if (inPlaneJoint) inPlaneJoint.localRotation = inPlaneHome;
        if (gantryJoint) gantryJoint.localPosition = gantryHome;
        if (columnHeightJoint) columnHeightJoint.localPosition = columnHome;
        if (gantryLRJoint) gantryLRJoint.localPosition = gantryLRHome;
        Physics.SyncTransforms();
    }

    Vector3 ToLocal(Transform t, Vector3 worldDir)
    {
        return t.parent != null
            ? t.parent.InverseTransformDirection(worldDir.normalized)
            : worldDir.normalized;
    }

    float DeepestPenetrationCm(out bool anyOverlap)
    {
        float worst = 0f;
        anyOverlap = false;

        foreach (Collider a in armColliders)
        {
            if (a == null) continue;
            foreach (Collider o in obstacleColliders)
            {
                if (o == null) continue;
                if (Physics.ComputePenetration(
                        a, a.transform.position, a.transform.rotation,
                        o, o.transform.position, o.transform.rotation,
                        out _, out float depth))
                {
                    anyOverlap = true;
                    float cm = depth * 100f;
                    if (cm > worst) worst = cm;
                }
            }
        }
        return worst;
    }

    void CastBeam()
    {
        if (focalSpot == null || detectorFace == null || coneMesh == null) return;

        Bounds b = coneMesh.bounds;
        Vector3 right = detectorFace.right;
        Vector3 up = detectorFace.up;
        float halfW = Vector3.Dot(b.extents, Abs(right));
        float halfH = Vector3.Dot(b.extents, Abs(up));

        Vector3 src = focalSpot.position;
        Vector3 corner = detectorFace.position - right * halfW - up * halfH;
        float stepX = raysPerSide > 1 ? 2f * halfW / (raysPerSide - 1) : 0f;
        float stepY = raysPerSide > 1 ? 2f * halfH / (raysPerSide - 1) : 0f;

        for (int iy = 0; iy < raysPerSide; iy++)
            for (int ix = 0; ix < raysPerSide; ix++)
            {
                Vector3 target = corner + right * (ix * stepX) + up * (iy * stepY);
                float len = Vector3.Distance(src, target);
                if (len < 1e-6f) continue;
                March(src, (target - src) / len, len);
            }
    }

    static Vector3 Abs(Vector3 v) =>
        new Vector3(Mathf.Abs(v.x), Mathf.Abs(v.y), Mathf.Abs(v.z));

    void March(Vector3 origin, Vector3 dir, float maxDist)
    {
        Vector3 local = origin - gridOrigin;
        int vx = Mathf.FloorToInt(local.x / voxelSizeM);
        int vy = Mathf.FloorToInt(local.y / voxelSizeM);
        int vz = Mathf.FloorToInt(local.z / voxelSizeM);

        int sx = dir.x >= 0 ? 1 : -1;
        int sy = dir.y >= 0 ? 1 : -1;
        int sz = dir.z >= 0 ? 1 : -1;

        float dx = Mathf.Abs(dir.x) > 1e-6f ? voxelSizeM / Mathf.Abs(dir.x) : float.MaxValue;
        float dy = Mathf.Abs(dir.y) > 1e-6f ? voxelSizeM / Mathf.Abs(dir.y) : float.MaxValue;
        float dz = Mathf.Abs(dir.z) > 1e-6f ? voxelSizeM / Mathf.Abs(dir.z) : float.MaxValue;

        float mx = dx < float.MaxValue
            ? (sx > 0 ? ((vx + 1) * voxelSizeM - local.x)
                      : (local.x - vx * voxelSizeM)) / Mathf.Abs(dir.x)
            : float.MaxValue;
        float my = dy < float.MaxValue
            ? (sy > 0 ? ((vy + 1) * voxelSizeM - local.y)
                      : (local.y - vy * voxelSizeM)) / Mathf.Abs(dir.y)
            : float.MaxValue;
        float mz = dz < float.MaxValue
            ? (sz > 0 ? ((vz + 1) * voxelSizeM - local.z)
                      : (local.z - vz * voxelSizeM)) / Mathf.Abs(dir.z)
            : float.MaxValue;

        float t = 0f;
        while (t < maxDist)
        {
            if (vx >= 0 && vx < nx && vy >= 0 && vy < ny && vz >= 0 && vz < nz)
                counts[Idx(vx, vy, vz)]++;

            if (mx < my && mx < mz) { t = mx; mx += dx; vx += sx; }
            else if (my < mz) { t = my; my += dy; vy += sy; }
            else { t = mz; mz += dz; vz += sz; }
        }
    }

    int Idx(int x, int y, int z) => x + nx * (y + ny * z);

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        if (head != null)
        {
            Gizmos.color = Color.magenta;
            Gizmos.DrawWireSphere(head.position, roiRadiusM);
        }
        if (focalSpot != null && detectorFace != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawLine(focalSpot.position, detectorFace.position);
        }
    }
#endif
}