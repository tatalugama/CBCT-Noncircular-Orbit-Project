using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIBuilder : MonoBehaviour
{
    [SerializeField] SequenceManager sequenceManager;

    void Start()
    {
        BuildUI();
    }

    void BuildUI()
    {
        // Canvas
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        canvasObj.AddComponent<GraphicRaycaster>();

        // Panel
        GameObject panel = new GameObject("UIPanel");
        panel.transform.SetParent(canvasObj.transform, false);
        RectTransform panelRT = panel.AddComponent<RectTransform>();
        panelRT.anchorMin = new Vector2(0, 1);
        panelRT.anchorMax = new Vector2(0, 1);
        panelRT.pivot = new Vector2(0, 1);
        panelRT.sizeDelta = new Vector2(420, 580);
        panelRT.anchoredPosition = new Vector2(10, -10);
        panel.AddComponent<Image>().color = new Color(0.1f, 0.1f, 0.1f, 0.9f);

        MakeText(panel.transform, "C-Arm Sequence Planner", 18, new Vector2(10, -10), new Vector2(400, 35));
        MakeText(panel.transform, "Type", 12, new Vector2(10, -50), new Vector2(120, 25));
        MakeText(panel.transform, "Degrees", 12, new Vector2(140, -50), new Vector2(80, 25));
        MakeText(panel.transform, "Secs", 12, new Vector2(230, -50), new Vector2(60, 25));

        // Scroll view
        GameObject scrollView = new GameObject("ScrollView");
        scrollView.transform.SetParent(panel.transform, false);
        RectTransform scrollRT = scrollView.AddComponent<RectTransform>();
        scrollRT.anchorMin = new Vector2(0, 0);
        scrollRT.anchorMax = new Vector2(1, 1);
        scrollRT.offsetMin = new Vector2(5, 120);
        scrollRT.offsetMax = new Vector2(-5, -78);
        ScrollRect scrollRect = scrollView.AddComponent<ScrollRect>();

        GameObject viewport = new GameObject("Viewport");
        viewport.transform.SetParent(scrollView.transform, false);
        RectTransform viewportRT = viewport.AddComponent<RectTransform>();
        viewportRT.anchorMin = Vector2.zero;
        viewportRT.anchorMax = Vector2.one;
        viewportRT.sizeDelta = Vector2.zero;
        viewport.AddComponent<Image>().color = new Color(0.05f, 0.05f, 0.05f, 1f);
        viewport.AddComponent<Mask>().showMaskGraphic = false;

        GameObject content = new GameObject("Content");
        content.transform.SetParent(viewport.transform, false);
        RectTransform contentRT = content.AddComponent<RectTransform>();
        contentRT.anchorMin = new Vector2(0, 1);
        contentRT.anchorMax = new Vector2(1, 1);
        contentRT.pivot = new Vector2(0.5f, 1);
        contentRT.sizeDelta = Vector2.zero;
        VerticalLayoutGroup vlg = content.AddComponent<VerticalLayoutGroup>();
        vlg.spacing = 3;
        vlg.padding = new RectOffset(3, 3, 3, 3);
        vlg.childForceExpandWidth = true;
        vlg.childForceExpandHeight = false;
        ContentSizeFitter csf = content.AddComponent<ContentSizeFitter>();
        csf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        scrollRect.content = contentRT;
        scrollRect.viewport = viewportRT;
        scrollRect.vertical = true;
        scrollRect.horizontal = false;
        scrollRect.scrollSensitivity = 30;

        // Add buttons row
        GameObject addRow = MakeRow(panel.transform, new Vector2(0, 78));
        Button addIPBtn = MakeButton(addRow.transform, "Add In-Plane", new Color(0.2f, 0.4f, 0.8f));
        Button addCCBtn = MakeButton(addRow.transform, "Add Cranio/Caudal", new Color(0.2f, 0.4f, 0.8f));

        // Play/Stop row
        GameObject playRow = MakeRow(panel.transform, new Vector2(0, 36));
        Button playBtn = MakeButton(playRow.transform, "Play", new Color(0.2f, 0.6f, 0.2f));
        Button stopBtn = MakeButton(playRow.transform, "Stop", new Color(0.7f, 0.2f, 0.2f));

        // Status bar
        GameObject statusObj = new GameObject("Status");
        statusObj.transform.SetParent(panel.transform, false);
        RectTransform statusRT = statusObj.AddComponent<RectTransform>();
        statusRT.anchorMin = new Vector2(0, 0);
        statusRT.anchorMax = new Vector2(1, 0);
        statusRT.pivot = new Vector2(0.5f, 0);
        statusRT.sizeDelta = new Vector2(-10, 28);
        statusRT.anchoredPosition = new Vector2(0, 6);
        statusObj.AddComponent<Image>().color = new Color(0.15f, 0.15f, 0.15f, 1f);
        TextMeshProUGUI statusText = MakeTextComponent(statusObj.transform, "Ready", 12);

        GameObject stepPrefab = BuildStepPrefab();

        sequenceManager.Setup(
            content.transform, stepPrefab,
            addIPBtn, addCCBtn,
            playBtn, stopBtn,
            statusText, panel);
    }

    GameObject MakeRow(Transform parent, Vector2 anchoredPos)
    {
        GameObject row = new GameObject("Row");
        row.transform.SetParent(parent, false);
        RectTransform rt = row.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0, 0);
        rt.anchorMax = new Vector2(1, 0);
        rt.pivot = new Vector2(0.5f, 0);
        rt.sizeDelta = new Vector2(-10, 38);
        rt.anchoredPosition = anchoredPos;
        HorizontalLayoutGroup hlg = row.AddComponent<HorizontalLayoutGroup>();
        hlg.spacing = 8;
        hlg.childForceExpandWidth = true;
        hlg.childForceExpandHeight = true;
        row.SetActive(false);
        return row;
    }

    GameObject BuildStepPrefab()
    {
        GameObject row = new GameObject("StepRow");
        row.AddComponent<RectTransform>().sizeDelta = new Vector2(0, 36);
        row.AddComponent<Image>().color = new Color(0.22f, 0.22f, 0.22f, 1f);
        HorizontalLayoutGroup hlg = row.AddComponent<HorizontalLayoutGroup>();
        hlg.spacing = 4;
        hlg.padding = new RectOffset(4, 4, 2, 2);
        hlg.childForceExpandHeight = true;
        hlg.childForceExpandWidth = false;
        LayoutElement rowLE = row.AddComponent<LayoutElement>();
        rowLE.preferredHeight = 36;
        rowLE.flexibleWidth = 1;

        // Label
        GameObject labelObj = new GameObject("Label");
        labelObj.transform.SetParent(row.transform, false);
        labelObj.AddComponent<LayoutElement>().preferredWidth = 120;
        labelObj.AddComponent<Image>().color = new Color(0, 0, 0, 0);
        MakeTextComponent(labelObj.transform, "Type", 12);

        MakeInputField(row.transform, "DegreesField", "90", 80);
        MakeInputField(row.transform, "DurationField", "1", 60);

        GameObject delObj = new GameObject("DeleteButton");
        delObj.transform.SetParent(row.transform, false);
        LayoutElement delLE = delObj.AddComponent<LayoutElement>();
        delLE.preferredWidth = 28;
        delLE.flexibleWidth = 0;
        delObj.AddComponent<Image>().color = new Color(0.6f, 0.15f, 0.15f, 1f);
        delObj.AddComponent<Button>();
        MakeTextComponent(delObj.transform, "X", 14);

        return row;
    }

    GameObject MakeInputField(Transform parent, string name, string defaultVal, float width)
    {
        GameObject obj = new GameObject(name);
        obj.transform.SetParent(parent, false);
        LayoutElement le = obj.AddComponent<LayoutElement>();
        le.preferredWidth = width;
        le.flexibleWidth = 0;
        obj.AddComponent<Image>().color = new Color(0.3f, 0.3f, 0.3f, 1f);
        TMP_InputField field = obj.AddComponent<TMP_InputField>();

        GameObject textArea = new GameObject("TextArea");
        textArea.transform.SetParent(obj.transform, false);
        RectTransform taRT = textArea.AddComponent<RectTransform>();
        taRT.anchorMin = Vector2.zero;
        taRT.anchorMax = Vector2.one;
        taRT.sizeDelta = new Vector2(-8, -4);
        taRT.anchoredPosition = Vector2.zero;
        textArea.AddComponent<RectMask2D>();

        GameObject placeholder = new GameObject("Placeholder");
        placeholder.transform.SetParent(textArea.transform, false);
        RectTransform phRT = placeholder.AddComponent<RectTransform>();
        phRT.anchorMin = Vector2.zero;
        phRT.anchorMax = Vector2.one;
        phRT.sizeDelta = Vector2.zero;
        TextMeshProUGUI phText = placeholder.AddComponent<TextMeshProUGUI>();
        phText.text = defaultVal;
        phText.fontSize = 12;
        phText.color = new Color(0.6f, 0.6f, 0.6f);
        phText.alignment = TextAlignmentOptions.Midline;

        GameObject textObj = new GameObject("Text");
        textObj.transform.SetParent(textArea.transform, false);
        RectTransform textRT = textObj.AddComponent<RectTransform>();
        textRT.anchorMin = Vector2.zero;
        textRT.anchorMax = Vector2.one;
        textRT.sizeDelta = Vector2.zero;
        TextMeshProUGUI inputText = textObj.AddComponent<TextMeshProUGUI>();
        inputText.fontSize = 12;
        inputText.color = Color.white;
        inputText.alignment = TextAlignmentOptions.Midline;

        field.textViewport = taRT;
        field.textComponent = inputText;
        field.placeholder = phText;
        field.text = defaultVal;
        field.contentType = TMP_InputField.ContentType.DecimalNumber;

        return obj;
    }

    Button MakeButton(Transform parent, string label, Color color)
    {
        GameObject obj = new GameObject(label);
        obj.transform.SetParent(parent, false);
        obj.AddComponent<Image>().color = color;
        Button btn = obj.AddComponent<Button>();
        MakeTextComponent(obj.transform, label, 13);
        return btn;
    }

    void MakeText(Transform parent, string content, int fontSize, Vector2 pos, Vector2 size)
    {
        GameObject obj = new GameObject("Text");
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0, 1);
        rt.anchorMax = new Vector2(0, 1);
        rt.pivot = new Vector2(0, 1);
        rt.sizeDelta = size;
        rt.anchoredPosition = new Vector2(pos.x, -pos.y);
        TextMeshProUGUI text = obj.AddComponent<TextMeshProUGUI>();
        text.text = content;
        text.fontSize = fontSize;
        text.color = Color.white;
        text.alignment = TextAlignmentOptions.MidlineLeft;
    }

    TextMeshProUGUI MakeTextComponent(Transform parent, string content, int fontSize)
    {
        GameObject obj = new GameObject("Txt");
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.sizeDelta = Vector2.zero;
        rt.anchoredPosition = Vector2.zero;
        TextMeshProUGUI text = obj.AddComponent<TextMeshProUGUI>();
        text.text = content;
        text.fontSize = fontSize;
        text.color = Color.white;
        text.alignment = TextAlignmentOptions.Midline;
        return text;
    }
}