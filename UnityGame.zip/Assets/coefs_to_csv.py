#!/usr/bin/env python3
"""
coefs_to_csv.py -- sinusoidal orbit COEFFICIENTS -> CSV of 3D source positions
readable by tuy_completeness.py.

tuy_completeness.py does:
    df = pd.read_csv(CSV_PATH, comment='#')
    src_loc_w = unity_to_ct_mm(df[['src_x','src_y','src_z']].to_numpy()).T
where unity_to_ct_mm() applies
    UNITY_UNITS_TO_MM = 1000.0          (1 unity unit = 1 m -> mm)
    UNITY_TO_CT_AXES  = ('x','z','y')   (ct_x=unity_x, ct_y=unity_z, ct_z=unity_y)

The orbit parameterisation produces CT-frame millimetres, so:

  --frame unity  (default)  write the INVERSE transform (mm -> unity units,
                            axes un-remapped) so tuy_completeness.py runs
                            with its config UNCHANGED.

  --frame ct                write CT millimetres directly.  Then set, in
                            tuy_completeness.py:
                                UNITY_UNITS_TO_MM = 1.0
                                UNITY_TO_CT_AXES  = ('x','y','z')

Centring: the orbit is built about --center-unity, given in RAW UNITY coords so
it can be matched to EVAL_LOCS_UNITY in tuy_completeness.py.  Default is
(0.0, 1.35, 3.5), i.e. the eval point already in that script.

Usage
  python coefs_to_csv.py                                # 300 proj, unity frame
  python coefs_to_csv.py --n-proj 500 --sad 600
  python coefs_to_csv.py --coefs 0.3 -0.24 0.45 0.28 -0.22 0.97 0.98 -0.35
  python coefs_to_csv.py --frame ct --out orbit_ct
  python coefs_to_csv.py --center-unity 0 1.35 3.5
"""

import argparse
import numpy as np

# --- must mirror tuy_completeness.py -----------------------------------------
UNITY_UNITS_TO_MM = 1000.0
UNITY_TO_CT_AXES = ('x', 'z', 'y')
_AXIS_IDX = {'x': 0, 'y': 1, 'z': 2}
_REMAP = [_AXIS_IDX[a] for a in UNITY_TO_CT_AXES]      # ct = unity[:, _REMAP]
_INV_REMAP = list(np.argsort(_REMAP))                  # unity = ct[:, _INV_REMAP]


def ct_mm_to_unity(points_mm):
    """Inverse of tuy_completeness.unity_to_ct_mm()."""
    points_mm = np.atleast_2d(points_mm)
    return points_mm[:, _INV_REMAP] / UNITY_UNITS_TO_MM


def sinusoidal_orbit(coefs, n_proj, n_harmonics, sad, sdd, max_phi, max_z, center):
    """coefs -> (src, det) in CT millimetres about `center` (CT mm).

    phi(theta) = max_phi * sum_h ( a_h sin(h.theta) + b_h cos(h.theta) )
    z(theta)   = max_z   * sum_h ( c_h sin(h.theta) + d_h cos(h.theta) )
    coefs layout: [ a_1..a_H | b_1..b_H | c_1..c_H | d_1..d_H ]
    """
    H = n_harmonics
    theta = np.linspace(0.0, 2 * np.pi, n_proj, endpoint=False)
    a, b = coefs[0:H], coefs[H:2 * H]
    c, d = coefs[2 * H:3 * H], coefs[3 * H:4 * H]

    phi = np.zeros_like(theta)
    z = np.zeros_like(theta)
    for h in range(1, H + 1):
        phi += a[h - 1] * np.sin(h * theta) + b[h - 1] * np.cos(h * theta)
        z += c[h - 1] * np.sin(h * theta) + d[h - 1] * np.cos(h * theta)
    phi = np.clip(max_phi * phi, -max_phi, max_phi)
    z = np.clip(max_z * z, -max_z, max_z)

    d_hat = np.stack([np.cos(phi) * np.cos(theta),
                      np.cos(phi) * np.sin(theta),
                      np.sin(phi)], axis=1)
    src = center + sad * d_hat
    src[:, 2] += z
    det = center - (sdd - sad) * d_hat
    det[:, 2] += z
    return theta, phi, z, src, det


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default="orbit_first_result.npz",
                    help="npz containing 'coefs'")
    ap.add_argument("--coefs", nargs="+", type=float, default=None,
                    help="coefficients directly instead of --in")
    ap.add_argument("--n-proj", type=int, default=300)
    ap.add_argument("--n-harmonics", type=int, default=None,
                    help="default: len(coefs)//4")
    ap.add_argument("--sad", type=float, default=350.0, help="mm")
    ap.add_argument("--sdd", type=float, default=700.0, help="mm")
    ap.add_argument("--max-phi-deg", type=float, default=50.0)
    ap.add_argument("--max-z", type=float, default=200.0, help="mm")
    ap.add_argument("--center-unity", nargs=3, type=float,
                    default=[0.0, 1.35, 3.5],
                    help="orbit centre in RAW UNITY coords (match EVAL_LOCS_UNITY)")
    ap.add_argument("--frame", choices=["unity", "ct"], default="unity")
    ap.add_argument("--out", default="orbit_for_tuy")
    args = ap.parse_args()

    # --- coefficients --------------------------------------------------------
    if args.coefs is not None:
        coefs = np.asarray(args.coefs, float)
    else:
        coefs = np.load(args.infile)["coefs"]
    if len(coefs) % 4 != 0:
        raise SystemExit(f"coefficient count {len(coefs)} is not a multiple of 4 "
                         "(layout [a|b|c|d], one block per harmonic)")
    H = args.n_harmonics if args.n_harmonics else len(coefs) // 4

    # --- orbit centre: unity -> CT mm, same transform the tuy script uses -----
    center_unity = np.asarray(args.center_unity, float)
    center_ct = np.atleast_2d(center_unity)[:, _REMAP][0] * UNITY_UNITS_TO_MM

    theta, phi, z, src_ct, det_ct = sinusoidal_orbit(
        coefs, args.n_proj, H, args.sad, args.sdd,
        np.deg2rad(args.max_phi_deg), args.max_z, center_ct)

    # --- write in the requested frame ---------------------------------------
    if args.frame == "unity":
        src_out, det_out = ct_mm_to_unity(src_ct), ct_mm_to_unity(det_ct)
        unit = "unity units (1 unit = 1 m), Unity Y-up axes"
    else:
        src_out, det_out = src_ct, det_ct
        unit = "CT-frame millimetres"

    path = f"{args.out}.csv"
    header_comments = (
        f"# sinusoidal orbit, {len(coefs)} coefficients, {H} harmonic(s)\n"
        f"# coefs = [{', '.join(f'{c:.6f}' for c in coefs)}]\n"
        f"# n_proj={args.n_proj} sad={args.sad}mm sdd={args.sdd}mm "
        f"max_phi={args.max_phi_deg}deg max_z={args.max_z}mm\n"
        f"# orbit centre (unity) = {center_unity.tolist()}\n"
        f"# orbit centre (ct mm) = {np.round(center_ct,3).tolist()}\n"
        f"# coordinate frame: {unit}\n"
    )
    with open(path, "w") as f:
        f.write(header_comments)
        f.write("i,theta_rad,phi_rad,z_mm,src_x,src_y,src_z,det_x,det_y,det_z\n")
        for i in range(len(theta)):
            f.write(f"{i},{theta[i]:.8f},{phi[i]:.8f},{z[i]:.6f},"
                    f"{src_out[i,0]:.8f},{src_out[i,1]:.8f},{src_out[i,2]:.8f},"
                    f"{det_out[i,0]:.8f},{det_out[i,1]:.8f},{det_out[i,2]:.8f}\n")

    # --- report --------------------------------------------------------------
    print(f"coefficients ({len(coefs)}) : {np.round(coefs, 3)}")
    print(f"harmonics               : {H}")
    print(f"projections             : {args.n_proj}")
    print(f"sad / sdd (mm)          : {args.sad} / {args.sdd}")
    print(f"phi range (deg)         : {np.rad2deg(phi).min():.2f} .. "
          f"{np.rad2deg(phi).max():.2f}")
    print(f"z range (mm)            : {z.min():.2f} .. {z.max():.2f}")
    print(f"orbit centre (unity)    : {center_unity.tolist()}")
    print(f"orbit centre (ct mm)    : {np.round(center_ct, 1).tolist()}")
    print(f"written frame           : {unit}")
    print(f"src range x (out units) : {src_out[:,0].min():.4f} .. {src_out[:,0].max():.4f}")
    print(f"src range y (out units) : {src_out[:,1].min():.4f} .. {src_out[:,1].max():.4f}")
    print(f"src range z (out units) : {src_out[:,2].min():.4f} .. {src_out[:,2].max():.4f}")
    print(f"\nwrote {path}")

    print("\nin tuy_completeness.py:")
    print(f"  CSV_PATH = r\"{path}\"")
    if args.frame == "unity":
        print("  (leave UNITY_UNITS_TO_MM and UNITY_TO_CT_AXES as they are)")
    else:
        print("  UNITY_UNITS_TO_MM = 1.0")
        print("  UNITY_TO_CT_AXES  = ('x','y','z')")
    print(f"  EVAL_LOCS_UNITY = np.array([{center_unity.tolist()}])   "
          "# orbit centre; add others as needed")


if __name__ == "__main__":
    main()
