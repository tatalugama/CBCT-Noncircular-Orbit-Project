using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.InputSystem;
using System.Collections;
using System.Collections.Generic;

public class SequenceManager : MonoBehaviour
{
    [Header("Targets")]
    [SerializeField] public Transform inPlaneJoint;
    [SerializeField] public Transform cranioCaudalJoint;

    Transform stepListParent;
    GameObject stepRowPrefab;
    Button addInPlaneButton;
    Button addCranioCaudalButton;
    Button playButton;
    Button stopButton;
    TextMeshProUGUI statusText;
    GameObject uiPanel;

    List<SequenceStep> steps = new List<SequenceStep>();
    Coroutine playCoroutine;

    public void Setup(Transform stepList, GameObject stepPrefab,
        Button addInPlane, Button addCC, Button play, Button stop,
        TextMeshProUGUI status, GameObject panel)
    {
        stepListParent = stepList;
        stepRowPrefab = stepPrefab;
        addInPlaneButton = addInPlane;
        addCranioCaudalButton = addCC;
        playButton = play;
        stopButton = stop;
        statusText = status;
        uiPanel = panel;

        addInPlaneButton.onClick.AddListener(() => AddStep(SequenceStep.RotationType.InPlane));
        addCranioCaudalButton.onClick.AddListener(() => AddStep(SequenceStep.RotationType.CranioCaudal));
        playButton.onClick.AddListener(StartSequence);
        stopButton.onClick.AddListener(StopSequence);
        stopButton.gameObject.SetActive(false);
        statusText.text = "Ready";
    }

    void Update()
    {
        if (Keyboard.current[Key.Tab].wasPressedThisFrame)
            uiPanel.SetActive(!uiPanel.activeSelf);
    }

    void AddStep(SequenceStep.RotationType type)
    {
        SequenceStep step = new SequenceStep();
        step.rotationType = type;
        steps.Add(step);

        GameObject row = Instantiate(stepRowPrefab, stepListParent);
        row.SetActive(true);
        TextMeshProUGUI label = row.transform.Find("Label/Txt").GetComponent<TextMeshProUGUI>();
        TMP_InputField degreesField = row.transform.Find("DegreesField").GetComponent<TMP_InputField>();
        TMP_InputField durationField = row.transform.Find("DurationField").GetComponent<TMP_InputField>();
        Button deleteButton = row.transform.Find("DeleteButton").GetComponent<Button>();

        label.text = type == SequenceStep.RotationType.InPlane ? "In-Plane" : "Cranio/Caudal";
        degreesField.text = "90";
        durationField.text = "1";
        step.degrees = 90f;
        step.duration = 1f;

        degreesField.onValueChanged.AddListener(val => {
            if (float.TryParse(val, out float result)) step.degrees = result;
        });
        durationField.onValueChanged.AddListener(val => {
            if (float.TryParse(val, out float result)) step.duration = result;
        });
        deleteButton.onClick.AddListener(() => {
            steps.Remove(step);
            Destroy(row);
        });
    }

    void StartSequence()
    {
        if (steps.Count == 0) return;
        playButton.gameObject.SetActive(false);
        stopButton.gameObject.SetActive(true);
        playCoroutine = StartCoroutine(PlaySequence());
    }

    void StopSequence()
    {
        if (playCoroutine != null) StopCoroutine(playCoroutine);
        playButton.gameObject.SetActive(true);
        stopButton.gameObject.SetActive(false);
        statusText.text = "Stopped";
    }

    IEnumerator PlaySequence()
    {
        while (true)
        {
            for (int i = 0; i < steps.Count; i++)
            {
                SequenceStep step = steps[i];
                statusText.text = $"Step {i + 1}/{steps.Count}: " +
                    $"{(step.rotationType == SequenceStep.RotationType.InPlane ? "In-Plane" : "Cranio/Caudal")} " +
                    $"{step.degrees}�";

                Transform joint = step.rotationType == SequenceStep.RotationType.InPlane
                    ? inPlaneJoint : cranioCaudalJoint;

                float elapsed = 0f;
                float rotated = 0f;

                while (elapsed < step.duration)
                {
                    elapsed += Time.deltaTime;
                    float t = Mathf.Clamp01(elapsed / step.duration);
                    float smoothT = Mathf.SmoothStep(0, 1, t);
                    float delta = (step.degrees * smoothT) - rotated;
                    rotated += delta;

                    if (step.rotationType == SequenceStep.RotationType.InPlane)
                        joint.Rotate(joint.right, delta, Space.World);
                    else
                        joint.Rotate(Vector3.right, delta, Space.World);

                    yield return null;
                }
            }
        }
    }
}