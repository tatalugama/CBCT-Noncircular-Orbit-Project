using UnityEngine;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

/// <summary>
/// Plays an orbit using EXACTLY the same pose math as OrbitScorer and reports
/// the same penetration numbers live. If this shows a collision, the scorer
/// saw it too. If it shows none, any red you see in the interactive system
/// comes from something outside OrbitScorer's watched pairs.
/// </summary>
public class OrbitPlayback : MonoBehaviour
{
    [Header("Joints � must match OrbitScorer exactly")]
    [SerializeField] Transform lateralJoint;
    [SerializeField] Transform cranioCaudalJoint;
    [SerializeField] Transform inPlaneJoint;
    [SerializeField] Transform gantryJoint;
    [SerializeField] Transform columnHeightJoint;
    [SerializeField] Transform gantryLRJoint;

    [Header("Translation directions � must match OrbitScorer")]
    [SerializeField] Vector3 gantryDir = Vector3.right;
    [SerializeField] Vector3 columnHeightDir = Vector3.up;
    [SerializeField] Vector3 gantryLRDir = Vector3.forward;

    [Header("Collision check � must match OrbitScorer")]
    [SerializeField] Transform[] armRoots;
    [SerializeField] string obstacleTag = "Obstacle";

    [Header("Orbit source")]
    [Tooltip("CSV in Assets/ � same file the optimizer writes")]
    [SerializeField] string csvFileName = "orbit_results_orbit.csv";
    [SerializeField] int projections = 300;

    [Header("Playback")]
    [SerializeField] bool playing = false;
    [SerializeField] float speed = 0.15f;
    [Range(0f, 1f)]
    [SerializeField] float position = 0f;

    const int NUM_STEPS = 8;
    const int NUM_DOF = 6;

    float[,] cum;
    bool loaded = false;

    Quaternion lateralHome, cranioCaudalHome, inPlaneHome;
    Vector3 gantryHome, columnHome, gantryLRHome;

    List<Collider> armColliders = new List<Collider>();
    List<Collider> obstacleColliders = new List<Collider>();

    string status = "no orbit loaded";
    int worstProjection = -1;
    float worstDepthCm = 0f;

    void Start()
    {
        CacheHome();
        CollectColliders();
        Load();
    }

    void CacheHome()
    {
        if (lateralJoint) lateralHome = lateralJoint.localRotation;
        if (cranioCaudalJoint) cranioCaudalHome = cranioCaudalJoint.localRotation;
        if (inPlaneJoint) inPlaneHome = inPlaneJoint.localRotation;
        if (gantryJoint) gantryHome = gantryJoint.localPosition;
        if (columnHeightJoint) columnHome = columnHeightJoint.localPosition;
        if (gantryLRJoint) gantryLRHome = gantryLRJoint.localPosition;
    }

    void CollectColliders()
    {
        armColliders.Clear();
        foreach (Transform root in armRoots)
        {
            if (root == null) continue;
            foreach (Collider c in root.GetComponentsInChildren<Collider>())
                if (!c.isTrigger && !armColliders.Contains(c))
                    armColliders.Add(c);
        }

        obstacleColliders.Clear();
        foreach (GameObject o in GameObject.FindGameObjectsWithTag(obstacleTag))
            obstacleColliders.AddRange(o.GetComponents<Collider>());

        Debug.Log($"[OrbitPlayback] {armColliders.Count} arm colliders, " +
                  $"{obstacleColliders.Count} obstacle colliders");
    }

    void Load()
    {
        string path = Path.Combine(Application.dataPath, csvFileName);
        if (!File.Exists(path))
        {
            status = $"not found: {csvFileName}";
            loaded = false;
            return;
        }

        try
        {
            var rows = new List<float[]>();
            foreach (string raw in File.ReadAllLines(path))
            {
                string line = raw.Trim();
                if (line.Length == 0) continue;

                string[] parts = line.Split(',');
                if (!float.TryParse(parts[0].Trim(), NumberStyles.Float,
                                    CultureInfo.InvariantCulture, out _))
                    continue;   // skip header

                var vals = new float[NUM_DOF];
                for (int d = 0; d < NUM_DOF; d++)
                    float.TryParse(parts[d].Trim(), NumberStyles.Float,
                                   CultureInfo.InvariantCulture, out vals[d]);
                rows.Add(vals);
            }

            if (rows.Count != NUM_STEPS)
            {
                status = $"expected {NUM_STEPS} rows, got {rows.Count}";
                loaded = false;
                return;
            }

            cum = new float[NUM_STEPS + 1, NUM_DOF];
            for (int s = 0; s < NUM_STEPS; s++)
                for (int d = 0; d < NUM_DOF; d++)
                    cum[s + 1, d] = cum[s, d] + rows[s][d];

            loaded = true;
            status = $"loaded {csvFileName}";
            ScanWholeOrbit();
        }
        catch (System.Exception e)
        {
            status = $"error: {e.Message}";
            loaded = false;
        }
    }

    void ScanWholeOrbit()
    {
        if (!loaded) return;

        worstDepthCm = 0f;
        worstProjection = -1;
        int touching = 0;

        for (int i = 0; i < projections; i++)
        {
            float u = projections > 1 ? (float)i / (projections - 1) : 1f;
            ApplyPose(u);
            Physics.SyncTransforms();

            float d = DeepestPenetrationCm();
            if (d > 0f) touching++;
            if (d > worstDepthCm) { worstDepthCm = d; worstProjection = i; }
        }

        Debug.Log($"[OrbitPlayback] scan: touching {touching}/{projections}, " +
                  $"worst {worstDepthCm:F2} cm at projection {worstProjection}");

        ApplyPose(position);
        Physics.SyncTransforms();
    }

    void Update()
    {
        if (!loaded) return;

        if (playing)
        {
            position += speed * Time.deltaTime;
            if (position > 1f) position -= 1f;
        }

        ApplyPose(position);
        Physics.SyncTransforms();
    }

    void ApplyPose(float u)
    {
        float x = Mathf.Clamp(u * NUM_STEPS, 0f, NUM_STEPS);
        int s = Mathf.Min(Mathf.FloorToInt(x), NUM_STEPS - 1);
        float frac = x - s;

        float lat = Mathf.Lerp(cum[s, 0], cum[s + 1, 0], frac);
        float crc = Mathf.Lerp(cum[s, 1], cum[s + 1, 1], frac);
        float inp = Mathf.Lerp(cum[s, 2], cum[s + 1, 2], frac);
        float gan = Mathf.Lerp(cum[s, 3], cum[s + 1, 3], frac);
        float col = Mathf.Lerp(cum[s, 4], cum[s + 1, 4], frac);
        float glr = Mathf.Lerp(cum[s, 5], cum[s + 1, 5], frac);

        if (lateralJoint)
            lateralJoint.localRotation =
                lateralHome * Quaternion.AngleAxis(lat, Vector3.right);
        if (cranioCaudalJoint)
            cranioCaudalJoint.localRotation =
                cranioCaudalHome * Quaternion.AngleAxis(crc, Vector3.up);
        if (inPlaneJoint)
            inPlaneJoint.localRotation =
                inPlaneHome * Quaternion.AngleAxis(inp, Vector3.forward);

        // Reset all translation joints to home first, then add contributions.
        // ColumnHeight and GantryLR share a Transform, so assigning separately
        // would silently discard the first write.
        if (gantryJoint) gantryJoint.localPosition = gantryHome;
        if (columnHeightJoint) columnHeightJoint.localPosition = columnHome;
        if (gantryLRJoint) gantryLRJoint.localPosition = gantryLRHome;

        if (gantryJoint)
            gantryJoint.localPosition += ToLocal(gantryJoint, gantryDir) * (gan / 100f);
        if (columnHeightJoint)
            columnHeightJoint.localPosition += ToLocal(columnHeightJoint, columnHeightDir) * (col / 100f);
        if (gantryLRJoint)
            gantryLRJoint.localPosition += ToLocal(gantryLRJoint, gantryLRDir) * (glr / 100f);
    }

    Vector3 ToLocal(Transform t, Vector3 worldDir)
    {
        return t.parent != null
            ? t.parent.InverseTransformDirection(worldDir.normalized)
            : worldDir.normalized;
    }

    float DeepestPenetrationCm()
    {
        float worst = 0f;
        foreach (Collider a in armColliders)
        {
            if (a == null) continue;
            foreach (Collider o in obstacleColliders)
            {
                if (o == null) continue;
                if (Physics.ComputePenetration(
                        a, a.transform.position, a.transform.rotation,
                        o, o.transform.position, o.transform.rotation,
                        out _, out float depth))
                {
                    float cm = depth * 100f;
                    if (cm > worst) worst = cm;
                }
            }
        }
        return worst;
    }

    void OnGUI()
    {
        GUI.Box(new Rect(600, 10, 380, 155), "Orbit Playback (scorer math)");
        float y = 40;

        GUI.Label(new Rect(610, y, 360, 20), status);
        y += 25;

        if (GUI.Button(new Rect(610, y, 90, 25), playing ? "Pause" : "Play"))
            playing = !playing;
        if (GUI.Button(new Rect(710, y, 90, 25), "Reload"))
            Load();
        if (GUI.Button(new Rect(810, y, 160, 25), "Go to worst"))
        {
            playing = false;
            position = projections > 1
                ? (float)worstProjection / (projections - 1) : 0f;
        }
        y += 32;

        GUI.Label(new Rect(610, y, 90, 20), $"u = {position:F3}");
        position = GUI.HorizontalSlider(new Rect(700, y + 5, 260, 20), position, 0f, 1f);
        y += 30;

        float now = loaded ? DeepestPenetrationCm() : 0f;
        GUI.color = now > 0f ? Color.red : Color.white;
        GUI.Label(new Rect(610, y, 360, 20),
                  $"now: {now:F2} cm    |    worst: {worstDepthCm:F2} cm at proj {worstProjection}");
        GUI.color = Color.white;
    }
}