using UnityEngine;
using UnityEngine.InputSystem;

public class HingeController : MonoBehaviour
{
    [SerializeField] LayerMask robotLayer;
    [SerializeField] int bufferSize;

    RaycastHit[] raycastHits;

    Hinge currentHinge;
    Plane hingePlane;
    Quaternion initialRot;

    // Debug
    Vector3 hingePos;
    Vector3 initPos;
    Vector3 currentPos;

    private void Start()
    {
        raycastHits = new RaycastHit[bufferSize];
    }

    private void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            TryGetHinge(out currentHinge);
        }
        if (Mouse.current.leftButton.isPressed)
        {
            if (TryGetPosOnHingePlane(out Vector3 pos))
            {
                currentPos = pos;

                Vector3 initDir = initPos - hingePos;
                Vector3 finalDir = currentPos - hingePos;
                Quaternion rot = Quaternion.FromToRotation(initDir, finalDir);

                currentHinge.transform.rotation = rot * initialRot;
            }
        }
    }

    public bool TryGetHinge(out Hinge hinge)
    {
        hinge = null;
        Vector2 mousePos = Mouse.current.position.ReadValue();
        Ray ray = Camera.main.ScreenPointToRay(mousePos);
        int count = Physics.RaycastNonAlloc(ray, raycastHits, float.PositiveInfinity, robotLayer);
        if (count == 0)
            return false;

        RaycastHit hit = default;
        float closestDist = float.PositiveInfinity;
        for (int i = 0; i < count; i++)
        {
            RaycastHit raycastHit = raycastHits[i];
            {
                if (raycastHit.distance < closestDist)
                {
                    closestDist = raycastHit.distance;
                    hit = raycastHit;
                }
            }
        }

        if ((hinge = hit.transform.GetComponentInParent<Hinge>()) == null)
            return false;

        Transform hingeTransform = hinge.transform;

        Vector3 dir = hit.point - hingeTransform.position;
        Vector3 offset = Vector3.Project(dir, hingeTransform.right);

        hingePos = hingeTransform.position + offset;
        Vector3 hingePivot = hingeTransform.right;
        hingePlane = new Plane(hingePivot, hingePos);

        hingePlane.Raycast(ray, out float distance);
        Vector3 pos = ray.GetPoint(distance);
        initPos = pos;

        initialRot = hingeTransform.rotation;

        return true;
    }

    public bool TryGetPosOnHingePlane(out Vector3 pos)
    {
        pos = Vector3.zero;
        if (currentHinge == null) return false;

        Vector2 mousePos = Mouse.current.position.ReadValue();
        Ray ray = Camera.main.ScreenPointToRay(mousePos);
        hingePlane.Raycast(ray, out float distance);
        pos = ray.GetPoint(distance);
        return true;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(hingePos, 0.1f);
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(initPos, 0.1f);
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(currentPos, 0.1f);
        Gizmos.color = Color.cyan;
        Gizmos.DrawLine(hingePos, initPos);
        Gizmos.color = Color.magenta;
        Gizmos.DrawLine(hingePos, currentPos);
    }
}